# Master Feng Shui Compass(全能玄學羅盤)

Melos monorepo。文件見 `docs/01–06`。

| Package | 內容 |
|---|---|
| `packages/fsc_domain` | 純 Dart 核心型別與引擎介面(零依賴) |
| `packages/fsc_engines` | 引擎實作(批次 7.1:曆法引擎) |
| `packages/fsc_ui` | 設計系統 tokens(玄金・宣紙) |

開發:`dart pub global activate melos && melos bootstrap && melos run test`
