import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_engines/fsc_engines.dart';
import 'package:test/test.dart';

void main() {
  group('九宮映射(立極八分法:方位定宮,與坐向無關)', () {
    const m = NinePalaceMapper();
    List<RoomPalace> run(double north, List<RoomShape> rooms) => m.map(
        rooms: rooms, jiJi: (x: 0, y: 0), northDeg: north,
        halfWidth: 10, halfHeight: 10);
    RoomShape room(String id, double cx, double cy) => RoomShape(
        id: id, kind: 'room',
        polygon: [(x: cx - 1.5, y: cy - 1.5), (x: cx + 1.5, y: cy - 1.5),
                  (x: cx + 1.5, y: cy + 1.5), (x: cx - 1.5, y: cy + 1.5)]);
    test('圖上=北:下方(南)→離、上方(北)→坎、右(東)→震、左(西)→兌', () {
      expect(run(0, [room('s', 0, 8)]).single.palace, Palace.li9);
      expect(run(0, [room('n', 0, -8)]).single.palace, Palace.kan1);
      expect(run(0, [room('e', 8, 0)]).single.palace, Palace.zhen3);
      expect(run(0, [room('w', -8, 0)]).single.palace, Palace.dui7);
    });
    test('對角:右上(東北)→艮、左下(西南)→坤', () {
      expect(run(0, [room('ne', 8, -8)]).single.palace, Palace.gen8);
      expect(run(0, [room('sw', -8, 8)]).single.palace, Palace.kun2);
    });
    test('中央→中宮', () {
      expect(run(0, [room('c', 0, 0)]).single.palace, Palace.center5);
    });
    test('平面圖上方朝東(northDeg=90):圖上方房間→震', () {
      // 圖上方位=90°(東)→ 上方房間實際在東 → 震宮
      expect(run(90, [room('up', 0, -8)]).single.palace, Palace.zhen3);
    });
    test('跨宮房間 coverage<1 供 UI 提示', () {
      final r = run(0, [room('edge', 10 / 3, 0)]);
      expect(r.single.coverage, lessThan(1));
    });
  });

  group('龍脈剖面', () {
    const a = DragonTerrainAnalyzer(prominenceM: 8);
    test('單峰單峽偵測(顯著鞍部)', () {
      final elev = [100.0, 130, 180, 150, 115, 150, 175, 140, 105, 90];
      final f = a.detect(elev);
      expect(f.where((p) => p.feature == TerrainFeature.peak).length,
          greaterThanOrEqualTo(1));
      expect(f.where((p) => p.feature == TerrainFeature.pass).length,
          greaterThanOrEqualTo(1));
    });
    test('平地無特徵、低分', () {
      final flat = List<double>.filled(30, 100);
      expect(a.detect(flat), isEmpty);
      expect(a.quality(flat).score, lessThanOrEqualTo(20));
    });
    test('起伏有致+末段緩降=高分', () {
      final good = <double>[
        for (var i = 0; i < 60; i++)
          300 - i * 2.5 + 40 * ((i % 20 < 10) ? (i % 10) / 10 : (10 - i % 10) / 10)
      ];
      final q = a.quality(good);
      expect(q.score, greaterThanOrEqualTo(60));
      expect(q.notes.any((n) => n.contains('結穴')), isTrue);
    });
  });
}
