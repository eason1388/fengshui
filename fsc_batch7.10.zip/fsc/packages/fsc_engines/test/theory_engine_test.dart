import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_engines/fsc_engines.dart';
import 'package:test/test.dart';

void main() {
  const ev = TheoryEvaluator();

  // 範例規則:二五交加且主臥在該宮 → 病符警告(03 §10.3)
  const rule25 = TheoryRule(
    id: 'xkfs_25_sick',
    kind: RuleKind.warning,
    condition: {
      'all': [
        {'fact': 'flying.palace.*.mountainStar', 'eq': 2, 'bindPalace': 'P'},
        {'fact': 'flying.palace.\$P.facingStar', 'eq': 5},
        {'fact': 'room.bedroom.palace', 'eq': '\$P'},
      ],
    },
    conclusion: {'verdict': 'xiong2', 'score': -8, 'subject': 'bedroom',
      'textKey': 'rule.xkfs.25_bedroom'},
    sourceRef: '沈氏玄空學·卷四',
  );
  final pack = TheoryPack(
      code: 'xuankong_shen', name: '沈氏玄空', version: '1.0.0', rules: [rule25]);

  group('DSL 評估器', () {
    test('bindPalace 命中:2/5 同宮且主臥在此', () {
      final facts = <String, Object?>{
        'flying.palace.li9.mountainStar': 2,
        'flying.palace.li9.facingStar': 5,
        'room.bedroom.palace': 'li9',
      };
      final hits = ev.run(pack, facts);
      expect(hits, hasLength(1));
      expect(hits.first.bindings['P'], 'li9');
      expect(hits.first.weightedScore, -8);
    });
    test('主臥不在 2/5 宮 → 不命中', () {
      final facts = <String, Object?>{
        'flying.palace.li9.mountainStar': 2,
        'flying.palace.li9.facingStar': 5,
        'room.bedroom.palace': 'kan1',
      };
      expect(ev.run(pack, facts), isEmpty);
    });
    test('回溯:坎離兩宮皆 2/5,主臥在離 → 須綁到離', () {
      final facts = <String, Object?>{
        'flying.palace.kan1.mountainStar': 2,
        'flying.palace.kan1.facingStar': 5,
        'flying.palace.li9.mountainStar': 2,
        'flying.palace.li9.facingStar': 5,
        'room.bedroom.palace': 'li9',
      };
      final hits = ev.run(pack, facts);
      expect(hits, hasLength(1));
      expect(hits.first.bindings['P'], 'li9');
    });
    test('withinDeg:向 178° 貼近 180±3', () {
      const r = TheoryRule(
        id: 't', kind: RuleKind.interpretation,
        condition: {'fact': 'bearing.facingDeg', 'withinDeg': [180, 3]},
        conclusion: {'score': 1}, sourceRef: 'test',
      );
      final p2 = TheoryPack(code: 'c', name: 'n', version: '1', rules: [r]);
      expect(ev.run(p2, {'bearing.facingDeg': 178.0}), hasLength(1));
      expect(ev.run(p2, {'bearing.facingDeg': 170.0}), isEmpty);
    });
    test('未知運算子 → FormatException(安全拒絕)', () {
      const bad = TheoryRule(
        id: 'b', kind: RuleKind.scoring,
        condition: {'fact': 'x', 'execute': 'rm -rf'},
        conclusion: {}, sourceRef: 'x',
      );
      final p3 = TheoryPack(code: 'c', name: 'n', version: '1', rules: [bad]);
      expect(() => ev.run(p3, {'x': 1}), throwsFormatException);
    });
  });

  group('綜合模式衝突偵測', () {
    test('兩派對同 subject 吉凶相反 → 列為衝突', () {
      const rA = TheoryRule(
        id: 'a', kind: RuleKind.interpretation,
        condition: {'fact': 'door.palace', 'eq': 'li9'},
        conclusion: {'subject': 'door', 'verdict': 'ji', 'score': 5},
        sourceRef: '甲派');
      const rB = TheoryRule(
        id: 'b', kind: RuleKind.interpretation,
        condition: {'fact': 'door.palace', 'eq': 'li9'},
        conclusion: {'subject': 'door', 'verdict': 'xiong', 'score': -5},
        sourceRef: '乙派');
      final runner = CompositeTheoryRunner(ev);
      final out = runner.runAll([
        (TheoryPack(code: 'A', name: 'A', version: '1', rules: const [rA]), 0.7),
        (TheoryPack(code: 'B', name: 'B', version: '1', rules: const [rB]), 0.3),
      ], {'door.palace': 'li9'});
      expect(out.conflicts, hasLength(1));
      expect(out.byPack['A']!.first.weightedScore, closeTo(3.5, 1e-9));
    });
  });
}
