import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_engines/fsc_engines.dart';
import 'package:test/test.dart';

void main() {
  const eng = DefaultFlyingStarEngine();

  group('已知名局(golden 錨點)', () {
    test('八運丑山未向=旺山旺向', () {
      final c = eng.natalChart(period: Period.p8, sitting: Mountain24.chou);
      expect(c.pattern, ChartPattern.wangShanWangXiang);
      expect(c.palaces[Palace.gen8]!.mountain, 8);
      expect(c.palaces[Palace.kun2]!.facing, 8);
    });
    test('八運子山午向=雙星會向(離宮 88)', () {
      final c = eng.natalChart(period: Period.p8, sitting: Mountain24.zi);
      expect(c.pattern, ChartPattern.doubleAtFacing);
      expect(c.palaces[Palace.li9]!.mountain, 8);
      expect(c.palaces[Palace.li9]!.facing, 8);
    });
    test('九運子山午向=雙星會坐', () {
      final c = eng.natalChart(period: Period.p9, sitting: Mountain24.zi);
      expect(c.pattern, ChartPattern.doubleAtSitting);
    });
    test('八運戌山辰向=上山下水', () {
      final c = eng.natalChart(period: Period.p8, sitting: Mountain24.xu);
      expect(c.pattern, ChartPattern.shangShanXiaShui);
    });
    test('八運旺山旺向恰 6 局(乾巽巳亥丑未)', () {
      final ws = Mountain24.values
          .where((m) =>
              eng.natalChart(period: Period.p8, sitting: m).pattern ==
              ChartPattern.wangShanWangXiang)
          .toSet();
      expect(ws, {
        Mountain24.qian, Mountain24.xun, Mountain24.si,
        Mountain24.hai, Mountain24.chou, Mountain24.wei,
      });
    });
  });

  group('替卦', () {
    test('八運子山午向替卦:山星 6 入中(巽→武曲)', () {
      final c = eng.natalChart(
          period: Period.p8, sitting: Mountain24.zi, tiGua: true);
      expect(c.palaces[Palace.center5]!.mountain, 6);
    });
  });

  group('結構驗證:432 盤山/向/運皆 1–9 全排列', () {
    test('下卦+替卦全掃', () {
      for (final p in Period.values) {
        for (final m in Mountain24.values) {
          for (final ti in [false, true]) {
            final c = eng.natalChart(period: p, sitting: m, tiGua: ti);
            for (final pick in [
              (PalaceStars s) => s.mountain,
              (PalaceStars s) => s.facing,
              (PalaceStars s) => s.base,
            ]) {
              final v = c.palaces.values.map(pick).toSet();
              expect(v, {1, 2, 3, 4, 5, 6, 7, 8, 9},
                  reason: '${p.number}運 ${m.zh} ti=$ti');
            }
          }
        }
      }
    });
  });

  group('八宅', () {
    const bz = DefaultBaZhaiEngine();
    test('坎宅:巽生氣、離延年、震天醫、艮五鬼、乾六煞、兌禍害、坤絕命', () {
      final c = bz.chart(Trigram.kan);
      expect(c.byGong[Trigram.xun], WanderingStar.shengQi);
      expect(c.byGong[Trigram.li], WanderingStar.yanNian);
      expect(c.byGong[Trigram.zhen], WanderingStar.tianYi);
      expect(c.byGong[Trigram.gen], WanderingStar.wuGui);
      expect(c.byGong[Trigram.qian], WanderingStar.liuSha);
      expect(c.byGong[Trigram.dui], WanderingStar.huoHai);
      expect(c.byGong[Trigram.kun], WanderingStar.jueMing);
      expect(c.byGong[Trigram.kan], WanderingStar.fuWei);
      expect(c.group, EastWest.east);
    });
    test('命卦:1984 男=兌、1984 女=艮', () {
      expect(bz.mingGua(suiYear: 1984, isMale: true), Trigram.dui);
      expect(bz.mingGua(suiYear: 1984, isMale: false), Trigram.gen);
    });
    test('宅卦:子山=坎宅、未山=坤宅', () {
      expect(bz.houseGua(Mountain24.zi), Trigram.kan);
      expect(bz.houseGua(Mountain24.wei), Trigram.kun);
    });
  });
}
