import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_engines/fsc_engines.dart';
import 'package:test/test.dart';

void main() {
  const it = DefaultBearingInterpreter();

  group('需求範例:278°', () {
    final r = it.interpret(const Azimuth(278), isSitting: true);
    test('辛山乙向', () => expect(r.title, '辛山乙向'));
    test('兼酉(向首偏逆時針 7°)→ 須替卦', () {
      expect(r.jian.isPure, isFalse);
      expect(r.jian.leanDeg, closeTo(-7, 0.01));
      expect(r.jian.leanTo, Mountain24.you);
      expect(r.jian.requiresTiGua, isTrue);
    });
    test('距酉辛界 0.5° → 騎縫警告', () {
      expect(r.warnings.whereType<QiFengLine>(), isNotEmpty);
    });
    test('落甲戌分金(孤,不可用)→ 差錯警告', () {
      expect(r.fenJin.name, '甲戌');
      expect(r.fenJin.quality, FenJinQuality.gu);
      expect(r.warnings.whereType<ChaCuoLine>(), isNotEmpty);
    });
  });

  group('正北 0°(子山午向)', () {
    final r = it.interpret(const Azimuth(0), isSitting: true);
    test('子山午向、正向不兼', () {
      expect(r.title, '子山午向');
      expect(r.jian.isPure, isTrue);
      expect(r.jian.requiresTiGua, isFalse);
    });
    test('落戊子龜甲空亡 → 空亡警告(正針中線教學點)', () {
      expect(r.fenJin.name, '戊子');
      expect(r.warnings.whereType<KongWangLine>(), isNotEmpty);
    });
    test('透地六十龍:0° 落丙子', () {
      // 子宮 345–15°,五龍各 6°:0° 落第三龍戊子(納音霹靂火)
      expect(r.dragon60.name, '戊子');
      expect(r.dragon60.naYin, '霹靂火');
    });
  });

  group('讀向模式(isSitting=false)', () {
    test('量得 98°(向)→ 坐 278 側:乙山?否——向在辛,坐在乙', () {
      final r = it.interpret(const Azimuth(278), isSitting: false);
      expect(r.title, '乙山辛向');
    });
  });

  group('資料表幾何(V1 鏡像)', () {
    test('三圈皆無縫覆蓋', () {
      for (final t in [fenJin120, dragons72, dragons60]) {
        expect(t.cells.length * t.span, 360, reason: t.code);
        for (var i = 0; i < t.cells.length; i++) {
          final cur = t.cells[i];
          final next = t.cells[(i + 1) % t.cells.length];
          expect(cur.endDeg, closeTo(next.startDeg, 1e-6),
              reason: '${t.code}#$i 接縫');
        }
      }
    });
    test('48 珠寶分金', () {
      final usable =
          fenJin120.cells.where((c) => c.quality?.usable ?? false).length;
      expect(usable, 48);
    });
    test('七十二龍=60 甲子+12 空亡', () {
      expect(dragons72.cells.where((c) => c.isBlank).length, 12);
      expect(dragons72.cells.where((c) => !c.isBlank).length, 60);
    });
    test('每山恰含 5 分金格', () {
      for (final m in Mountain24.values) {
        final inMountain = fenJin120.cells.where((c) {
          final mid = ((c.startDeg + 1.5) % 360);
          return Mountain24.fromAzimuth(Azimuth(mid)) == m;
        }).length;
        expect(inMountain, 5, reason: m.zh);
      }
    });
  });
}
