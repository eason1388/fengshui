import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_engines/fsc_engines.dart';
import 'package:test/test.dart';

void main() {
  const engine = DefaultCalendarEngine();

  group('日柱錨點(權威錨,02 §4 calendar_check)', () {
    GanZhi dayOf(int y, int m, int d) => engine
        .fourPillars(DateTime(y, m, d, 12), utcOffsetMinutes: 480)
        .day;
    test('2000-01-01 戊午日', () => expect(dayOf(2000, 1, 1).zh, '戊午'));
    test('2000-01-07 甲子日', () => expect(dayOf(2000, 1, 7).zh, '甲子'));
    test('1900-01-01 甲戌日', () => expect(dayOf(1900, 1, 1).zh, '甲戌'));
    test('晚子時 23:30 換翌日', () {
      final p = engine.fourPillars(DateTime(2000, 1, 6, 23, 30),
          utcOffsetMinutes: 480);
      expect(p.day.zh, '甲子');
    });
  });

  group('節氣(容差 ±20 分,正式值以資料包為準)', () {
    test('2024 春分 ≈ 2024-03-20 03:06 UTC', () {
      final t = engine.termInstant(2024, SolarTermType.chunFen);
      final ref = DateTime.utc(2024, 3, 20, 3, 6);
      expect(t.difference(ref).inMinutes.abs(), lessThan(20));
    });
    test('立春必在 2/3–2/5(1950–2050 抽驗)', () {
      for (var y = 1950; y <= 2050; y += 10) {
        final t = engine.termInstant(y, SolarTermType.liChun)
            .add(const Duration(hours: 8)); // 東八區
        expect(t.month, 2);
        expect(t.day, inInclusiveRange(3, 5), reason: '$y 年立春 $t');
      }
    });
  });

  group('四柱整排', () {
    test('2000-01-01 12:00 北京 → 己卯年 丙子月 戊午日 戊午時', () {
      final p = engine.fourPillars(DateTime(2000, 1, 1, 12),
          utcOffsetMinutes: 480);
      expect(p.toString(), contains('己卯年'));
      expect(p.month.zh, '丙子');
      expect(p.day.zh, '戊午');
      expect(p.hour.zh, '戊午');
    });
    test('立春前後年柱切換(2000-02-04 前後)', () {
      final before = engine.fourPillars(DateTime(2000, 2, 3, 12),
          utcOffsetMinutes: 480);
      final after = engine.fourPillars(DateTime(2000, 2, 6, 12),
          utcOffsetMinutes: 480);
      expect(before.year.zh, '己卯');
      expect(after.year.zh, '庚辰');
    });
  });
}
