import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_engines/fsc_engines.dart';
import 'package:test/test.dart';

void main() {
  const zb = DefaultZiBaiEngine(DefaultCalendarEngine());
  const ss = DefaultShenShaEngine(zb);

  group('年星(已知錨點)', () {
    test('2017=1、2024=3、2025=2、2026=1', () {
      expect([2017, 2024, 2025, 2026].map(zb.annualStar), [1, 3, 2, 1]);
    });
    test('五黃:2024兌(西)、2025艮(東北)、2026離(南)', () {
      Palace wh(int y) =>
          zb.annual(y).entries.firstWhere((e) => e.value == 5).key;
      expect([wh(2024), wh(2025), wh(2026)],
          [Palace.dui7, Palace.gen8, Palace.li9]);
    });
  });

  group('月星', () {
    test('2026(午年)寅月8、卯月7;2024(辰年)寅月5', () {
      expect(zb.monthStar(2026, 0), 8);
      expect(zb.monthStar(2026, 1), 7);
      expect(zb.monthStar(2024, 0), 5);
    });
  });

  group('日星(三元遁)', () {
    test('冬至後首甲子=1白順行;夏至後甲子逆行', () {
      final dz = jdnFromCivil(2025, 12, 21);
      final jiaZi = dz + ((-(dz - 11)) % 60 + 60) % 60;
      expect(zb.dailyStar(jiaZi, [(dz, 1, true)]).$1, 1);
      expect(zb.dailyStar(jiaZi + 1, [(dz, 1, true)]).$1, 2);
      final xz = jdnFromCivil(2026, 6, 21);
      final jz2 = xz + ((-(xz - 11)) % 60 + 60) % 60;
      expect(zb.dailyStar(jz2 + 1, [(xz, 9, false)]).$1, 8);
    });
  });

  group('時星', () {
    test('陽遁子日子時1、丑時2;陰遁子日子時9', () {
      expect(zb.hourStar(Branch.zi, 0, yangDun: true), 1);
      expect(zb.hourStar(Branch.zi, 1, yangDun: true), 2);
      expect(zb.hourStar(Branch.zi, 0, yangDun: false), 9);
    });
  });

  group('年神煞', () {
    test('2026:太歲午、歲破子、三煞亥子丑、五黃離', () {
      final a = ss.annual(2026);
      expect(a.taiSui, Branch.wuma);
      expect(a.suiPo, Branch.zi);
      expect(a.sanSha, [Branch.hai, Branch.zi, Branch.chou]);
      expect(a.wuHuang, Palace.li9);
    });
    test('2024:三煞巳午未(申子辰煞南)', () {
      expect(ss.annual(2024).sanSha, [Branch.si, Branch.wuma, Branch.wei]);
    });
  });

  group('個人吉位', () {
    test('甲子年生:文昌巳、桃花酉、驛馬寅、貴人丑未', () {
      final p = ss.personal(GanZhi.of(Stem.jia, Branch.zi));
      expect(p.wenChang, Branch.si);
      expect(p.taoHua, Branch.you);
      expect(p.yiMa, Branch.yin);
      expect(p.guiRen, [Branch.chou, Branch.wei]);
    });
  });
}
