import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_engines/fsc_engines.dart';
import 'package:test/test.dart';

void main() {
  const cal = DefaultCalendarEngine();
  const eng = DefaultBaziEngine(cal);

  group('十神固定表(甲日主)', () {
    test('全 10 干', () {
      const exp = {
        Stem.jia: TenGod.biJian, Stem.yi: TenGod.jieCai,
        Stem.bing: TenGod.shiShen, Stem.ding: TenGod.shangGuan,
        Stem.wu: TenGod.pianCai, Stem.ji: TenGod.zhengCai,
        Stem.geng: TenGod.qiSha, Stem.xin: TenGod.zhengGuan,
        Stem.ren: TenGod.pianYin, Stem.gui: TenGod.zhengYin,
      };
      exp.forEach((s, t) => expect(eng.tenGod(Stem.jia, s), t, reason: s.zh));
    });
  });

  group('整盤:2000-01-01 12:00 +8 男', () {
    final pillars = cal.fourPillars(DateTime(2000, 1, 1, 12), utcOffsetMinutes: 480);
    final chart = eng.compute(pillars: pillars, isMale: true, daysToJie: 25);
    test('日主戊、月干丙=偏印', () {
      expect(chart.dayMaster, Stem.wu);
      expect(chart.tenGods['month'], TenGod.pianYin);
    });
    test('水最強(子月得令)', () {
      final maxWx = chart.strength.points.entries
          .reduce((a, b) => a.value >= b.value ? a : b).key;
      expect(maxWx, WuXing.water);
    });
    test('己年男逆排、首運乙亥、起運≈8.3歲', () {
      expect(chart.forward, isFalse);
      expect(chart.daYun.first.pillar.zh, '乙亥');
      expect(chart.daYun.first.startAge, closeTo(25 / 3, 1e-9));
    });
  });

  group('八字×風水整合', () {
    const integ = BaziFengShuiIntegrator();
    const xk = DefaultFlyingStarEngine();
    const bzE = DefaultBaZhaiEngine();
    test('喜火土×八運丑山(旺山旺向、坐土)高分', () {
      final pillars = cal.fourPillars(DateTime(2000, 1, 1, 12), utcOffsetMinutes: 480);
      var chart = eng.compute(pillars: pillars, isMale: true, daysToJie: 25);
      final house = xk.natalChart(period: Period.p8, sitting: Mountain24.chou);
      final r = integ.analyze(
          owner: chart, house: house, baZhai: bzE.chart(Trigram.gen));
      expect(r.score, greaterThanOrEqualTo(75));
      expect(r.items.any((i) => i.ruleId == 'xk.pattern' && i.delta == 25), isTrue);
      // 可解釋性:每項必有出處
      expect(r.items.every((i) => i.sourceRef.isNotEmpty), isTrue);
    });
    test('上山下水拉低總分', () {
      final pillars = cal.fourPillars(DateTime(2000, 1, 1, 12), utcOffsetMinutes: 480);
      final chart = eng.compute(pillars: pillars, isMale: true, daysToJie: 25);
      final house = xk.natalChart(period: Period.p8, sitting: Mountain24.xu);
      final r = integ.analyze(
          owner: chart, house: house, baZhai: bzE.chart(Trigram.qian));
      expect(r.score, lessThan(60));
    });
  });
}
