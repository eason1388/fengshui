import 'package:fsc_domain/fsc_domain.dart';

/// 玄空飛星引擎(沈氏通行法)。
///
/// 演算法要點(已由 432 盤 golden 與已知名局驗證,data/golden):
/// * 運盤:運星入中順飛。
/// * 山/向星:運盤到坐/向宮之星入中;順逆依「該星卦宮同元龍山」之陰陽。
/// * 五黃無卦:陰陽借坐(向)山本身之元龍陰陽。
/// * 替卦:改以同元龍山之替星入中(口訣:子癸甲申貪狼、壬卯乙未坤巨門、
///   乾亥辰巽巳戌武曲、酉辛丑艮丙破軍、寅午庚丁右弼)。出處:沈氏玄空學。
final class DefaultFlyingStarEngine {
  /// 建立。
  const DefaultFlyingStarEngine();

  /// 引擎版本。
  String get version => 'xuankong-1.0.0';

  /// 飛泊宮序:中→乾→兌→艮→離→坎→坤→震→巽。
  static const _flyOrder = [
    Palace.center5, Palace.qian6, Palace.dui7, Palace.gen8, Palace.li9,
    Palace.kan1, Palace.kun2, Palace.zhen3, Palace.xun4,
  ];

  /// 替星口訣。
  static const _tiStar = <Mountain24, int>{
    Mountain24.zi: 1, Mountain24.gui: 1, Mountain24.jia: 1, Mountain24.shen: 1,
    Mountain24.ren: 2, Mountain24.mao: 2, Mountain24.yi: 2, Mountain24.wei: 2,
    Mountain24.kun: 2,
    Mountain24.qian: 6, Mountain24.hai: 6, Mountain24.chen: 6,
    Mountain24.xun: 6, Mountain24.si: 6, Mountain24.xu: 6,
    Mountain24.you: 7, Mountain24.xin: 7, Mountain24.chou: 7,
    Mountain24.gen: 7, Mountain24.bing: 7,
    Mountain24.yin: 9, Mountain24.wu: 9, Mountain24.geng: 9, Mountain24.ding: 9,
  };

  /// 入中飛泊。
  Map<Palace, int> _fly(int center, {required bool forward}) {
    final out = <Palace, int>{};
    var s = center;
    for (final p in _flyOrder) {
      out[p] = s;
      s = forward ? s % 9 + 1 : (s - 2 + 9) % 9 + 1;
    }
    return out;
  }

  /// 排宅盤(下卦或替卦)。
  FlyingStarChart natalChart({
    required Period period,
    required Mountain24 sitting,
    bool tiGua = false,
  }) {
    final facing = sitting.opposite;
    final base = _fly(period.number, forward: true);
    final kind = sitting.dragon;

    Map<Palace, int> starChart(Palace pal, Mountain24 refIfFive) {
      final s = base[pal]!;
      if (s == 5) return _fly(5, forward: refIfFive.isYangDragon);
      final refM = PalaceLuoShu.fromNumber(s).mountains[kind.index];
      final enter = tiGua ? _tiStar[refM]! : s;
      return _fly(enter, forward: refM.isYangDragon);
    }

    final mt = starChart(sitting.palace, sitting);
    final fc = starChart(facing.palace, facing);

    final palaces = {
      for (final p in _flyOrder)
        p: PalaceStars(palace: p, mountain: mt[p]!, facing: fc[p]!, base: base[p]!),
    };

    final n = period.number;
    final pattern = mt[sitting.palace] == n && fc[facing.palace] == n
        ? ChartPattern.wangShanWangXiang
        : mt[facing.palace] == n && fc[sitting.palace] == n
            ? ChartPattern.shangShanXiaShui
            : mt[facing.palace] == n && fc[facing.palace] == n
                ? ChartPattern.doubleAtFacing
                : mt[sitting.palace] == n && fc[sitting.palace] == n
                    ? ChartPattern.doubleAtSitting
                    : ChartPattern.other;

    return FlyingStarChart(
      period: period,
      sitting: sitting,
      facing: facing,
      isTiGua: tiGua,
      palaces: palaces,
      pattern: pattern,
      sanBan: _sanBan(palaces),
      gates: _gates(base, facing, kind),
      warnings: _fuYin(mt, fc),
    );
  }

  SanBanGua? _sanBan(Map<Palace, PalaceStars> ps) {
    const tri = [{1, 4, 7}, {2, 5, 8}, {3, 6, 9}];
    // 注意:三星必須「恰為」三個相異數,重複(如 1-1-4)不算三般卦。
    final parent = ps.values.every((s) {
      final set = {s.mountain, s.facing, s.base};
      return set.length == 3 && tri.any((t) => t.containsAll(set));
    });
    if (parent) return SanBanGua.parent;
    final lianZhu = ps.values.every((s) {
      final v = [s.mountain, s.facing, s.base]..sort();
      final d1 = (v[1] - v[0] + 9) % 9;
      final d2 = (v[2] - v[1] + 9) % 9;
      return {d1, d2} == {1} || (d1 == 1 && d2 == 7) || (d1 == 7 && d2 == 1);
    });
    return lianZhu ? SanBanGua.lianZhu : null;
  }

  List<ChengMen> _gates(Map<Palace, int> base, Mountain24 facing, SanYuanDragon kind) {
    // 向宮左右兩宮;與向宮洛書數合生成(1-6,2-7,3-8,4-9)者為正城門;
    // 可用=該宮同元龍山屬陰(逆飛令當運星到宮)。
    const adj = <Palace, (Palace, Palace)>{
      Palace.kan1: (Palace.qian6, Palace.gen8),
      Palace.gen8: (Palace.kan1, Palace.zhen3),
      Palace.zhen3: (Palace.gen8, Palace.xun4),
      Palace.xun4: (Palace.zhen3, Palace.li9),
      Palace.li9: (Palace.xun4, Palace.kun2),
      Palace.kun2: (Palace.li9, Palace.dui7),
      Palace.dui7: (Palace.kun2, Palace.qian6),
      Palace.qian6: (Palace.dui7, Palace.kan1),
    };
    const gen = {1: 6, 6: 1, 2: 7, 7: 2, 3: 8, 8: 3, 4: 9, 9: 4};
    final fp = facing.palace;
    final pair = adj[fp]!;
    return [pair.$1, pair.$2].map((gp) {
      final s = base[gp]!;
      var usable = false;
      if (s != 5) {
        usable = !PalaceLuoShu.fromNumber(s).mountains[kind.index].isYangDragon;
      }
      return ChengMen(
        palace: gp,
        isPrimary: gen[fp.number] == gp.number,
        usable: usable,
      );
    }).toList();
  }

  List<String> _fuYin(Map<Palace, int> mt, Map<Palace, int> fc) {
    final w = <String>[];
    for (final (name, cc) in [('mountain', mt), ('facing', fc)]) {
      final fu = cc.entries.every((e) => e.value == e.key.number);
      final fan = cc.entries.every(
          (e) => e.key == Palace.center5 ? e.value == 5 : e.value + e.key.number == 10);
      if (fu) w.add('warning.fuyin.$name');
      if (fan) w.add('warning.fanyin.$name');
    }
    return w;
  }
}
