import 'package:fsc_domain/fsc_domain.dart';

/// 事實集:扁平 fact 路徑 → 值(03 §10.2)。
/// 由各引擎輸出組裝,例:flying.palace.li9.facingStar=8。
typedef FactContext = Map<String, Object?>;

/// DSL 評估器。
///
/// 支援運算子:eq/neq/gt/gte/lt/lte/in/withinDeg、all/any/not。
/// 萬用宮位:fact 路徑中的 `*` 逐宮嘗試,`bindPalace` 記名綁定,
/// 之後以 `$P` 引用。安全性:純資料驅動、無迴圈、未知運算子即拒絕。
final class TheoryEvaluator {
  /// 建立。
  const TheoryEvaluator();

  /// 版本。
  String get version => 'theory-1.0.0';

  static const _palaces = [
    'kan1', 'kun2', 'zhen3', 'xun4', 'center5', 'qian6', 'dui7', 'gen8', 'li9',
  ];

  /// 對事實集執行整包規則。
  List<RuleHit> run(TheoryPack pack, FactContext facts, {String scope = 'yangzhai'}) {
    final hits = <RuleHit>[];
    for (final rule in pack.rules) {
      if (!rule.scope.contains(scope)) continue;
      final b = <String, String>{};
      if (_eval(rule.condition, facts, b)) {
        final score = (rule.conclusion['score'] as num?)?.toDouble() ?? 0;
        hits.add(RuleHit(
            rule: rule, bindings: Map.of(b), weightedScore: score * rule.weight));
      }
    }
    return hits;
  }

  /// `all` 條件鏈之回溯求解:萬用宮位綁定失敗時嘗試下一宮,
  /// 確保「存在某宮同時滿足整串條件」的語意(而非貪婪首綁)。
  bool _evalAllBacktrack(List<Map<String, dynamic>> list, int i, FactContext f,
      Map<String, String> b) {
    if (i == list.length) return true;
    final node = list[i];
    final path = node['fact'] as String?;
    if (path != null && path.contains('*')) {
      final bindAs = node['bindPalace'] as String? ?? 'P';
      for (final p in _palaces) {
        if (b.containsKey(bindAs) && b[bindAs] != p) continue;
        final trial = Map.of(b)..[bindAs] = p;
        final resolved = Map<String, dynamic>.of(node)
          ..['fact'] = path.replaceFirst('*', p)
          ..remove('bindPalace');
        if (_eval(resolved, f, trial) &&
            _evalAllBacktrack(list, i + 1, f, trial)) {
          b
            ..clear()
            ..addAll(trial);
          return true;
        }
      }
      return false;
    }
    return _eval(node, f, b) && _evalAllBacktrack(list, i + 1, f, b);
  }

  bool _eval(Map<String, dynamic> node, FactContext f, Map<String, String> b) {
    if (node.containsKey('all')) {
      final list = (node['all'] as List)
          .map((n) => (n as Map).cast<String, dynamic>())
          .toList();
      return _evalAllBacktrack(list, 0, f, b);
    }
    if (node.containsKey('any')) {
      return (node['any'] as List)
          .any((n) => _eval((n as Map).cast<String, dynamic>(), f, b));
    }
    if (node.containsKey('not')) {
      return !_eval((node['not'] as Map).cast<String, dynamic>(), f, b);
    }
    final path = node['fact'] as String?;
    if (path == null) throw FormatException('規則缺 fact:$node');

    // 萬用宮位:含 * 時逐宮嘗試並綁定。
    if (path.contains('*')) {
      final bindAs = node['bindPalace'] as String? ?? 'P';
      for (final p in _palaces) {
        if (b.containsKey(bindAs) && b[bindAs] != p) continue;
        final resolved = Map<String, dynamic>.of(node)
          ..['fact'] = path.replaceFirst('*', p)
          ..remove('bindPalace');
        final trial = Map.of(b)..[bindAs] = p;
        if (_eval(resolved, f, trial)) {
          b
            ..clear()
            ..addAll(trial);
          return true;
        }
      }
      return false;
    }

    // $變數 代換
    final real = path.replaceAllMapped(
        RegExp(r'\$(\w+)'), (m) => b[m[1]] ?? (throw FormatException('未綁定 \$${m[1]}')));
    final v = f[real];

    Object? expected(String op) {
      final e = node[op];
      return e is String && e.startsWith(r'$') ? b[e.substring(1)] : e;
    }

    for (final op in ['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'in', 'withinDeg']) {
      if (!node.containsKey(op)) continue;
      final e = expected(op);
      switch (op) {
        case 'eq':
          return v == e;
        case 'neq':
          return v != e;
        case 'gt':
          return (v as num) > (e! as num);
        case 'gte':
          return (v as num) >= (e! as num);
        case 'lt':
          return (v as num) < (e! as num);
        case 'lte':
          return (v as num) <= (e! as num);
        case 'in':
          return (e! as List).contains(v);
        case 'withinDeg':
          final args = (e! as List).cast<num>(); // [target, tol]
          final d = ((v! as num) - args[0]).abs() % 360;
          return (d > 180 ? 360 - d : d) <= args[1];
      }
    }
    throw FormatException('未知運算子:$node');
  }
}

/// 綜合模式:多包並跑、衝突並列(01 FR-I)。
final class CompositeTheoryRunner {
  /// 建立。
  const CompositeTheoryRunner(this.evaluator);

  /// 評估器。
  final TheoryEvaluator evaluator;

  /// 執行多包(各附權重),回傳各包命中與衝突清單。
  ({Map<String, List<RuleHit>> byPack, List<(RuleHit, RuleHit)> conflicts})
      runAll(List<(TheoryPack, double)> packs, FactContext facts,
          {String scope = 'yangzhai'}) {
    final byPack = <String, List<RuleHit>>{};
    for (final (pack, w) in packs) {
      byPack[pack.code] = evaluator
          .run(pack, facts, scope: scope)
          .map((h) => RuleHit(
              rule: h.rule,
              bindings: h.bindings,
              weightedScore: h.weightedScore * w))
          .toList();
    }
    // 衝突:不同包對同一 subject(conclusion.subject)給出相反 verdict。
    final all = byPack.values.expand((x) => x).toList();
    final conflicts = <(RuleHit, RuleHit)>[];
    for (var i = 0; i < all.length; i++) {
      for (var j = i + 1; j < all.length; j++) {
        final a = all[i], c = all[j];
        final subjA = a.rule.conclusion['subject'];
        if (subjA != null && subjA == c.rule.conclusion['subject']) {
          final va = a.rule.conclusion['verdict'] as String?;
          final vc = c.rule.conclusion['verdict'] as String?;
          if (va != null && vc != null && va.startsWith('ji') != vc.startsWith('ji')) {
            conflicts.add((a, c));
          }
        }
      }
    }
    return (byPack: byPack, conflicts: conflicts);
  }
}
