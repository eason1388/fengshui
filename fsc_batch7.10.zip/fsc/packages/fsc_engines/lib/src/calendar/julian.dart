/// 儒略日工具。天文計算與日柱推算的共同基礎。
library;

/// 公曆日期(年月日)→ 儒略日數 JDN(中午 12:00 UT 起算之整數)。
/// Fliegel–Van Flandern 演算法;適用 1583 年後公曆。
int jdnFromCivil(int year, int month, int day) {
  final a = (14 - month) ~/ 12;
  final y = year + 4800 - a;
  final m = month + 12 * a - 3;
  return day +
      (153 * m + 2) ~/ 5 +
      365 * y +
      y ~/ 4 -
      y ~/ 100 +
      y ~/ 400 -
      32045;
}

/// UTC 時刻 → 儒略日(JD,含小數)。
double jdFromUtc(DateTime utc) {
  assert(utc.isUtc, '必須傳入 UTC 時刻');
  final dayFrac =
      (utc.hour - 12) / 24 + utc.minute / 1440 + (utc.second + utc.millisecond / 1000) / 86400;
  return jdnFromCivil(utc.year, utc.month, utc.day) + dayFrac;
}

/// JD → UTC 時刻(反向,秒級精度)。
DateTime utcFromJd(double jd) {
  final z = (jd + 0.5).floor();
  final f = jd + 0.5 - z;
  var a = z;
  if (z >= 2299161) {
    final alpha = ((z - 1867216.25) / 36524.25).floor();
    a = z + 1 + alpha - alpha ~/ 4;
  }
  final b = a + 1524;
  final c = ((b - 122.1) / 365.25).floor();
  final d = (365.25 * c).floor();
  final e = ((b - d) / 30.6001).floor();
  final dayWithFrac = b - d - (30.6001 * e).floor() + f;
  final day = dayWithFrac.floor();
  final month = e < 14 ? e - 1 : e - 13;
  final year = month > 2 ? c - 4716 : c - 4715;
  final secs = ((dayWithFrac - day) * 86400).round();
  return DateTime.utc(year, month, day).add(Duration(seconds: secs));
}

/// ΔT(TT − UT,秒)近似:1900–2100 分段多項式(Espenak & Meeus)。
/// 曆法用途誤差 <±5s,遠小於節氣判界容差;正式資料包(solar_terms 表)
/// 由更高精度來源編譯,本函數為引擎內建後援(02 §2.4)。
double deltaTSeconds(int year) {
  final y = year.toDouble();
  if (y >= 2050) {
    final t = (y - 1820) / 100;
    return -20 + 32 * t * t - 0.5628 * (2150 - y);
  }
  if (y >= 2005) {
    final t = y - 2000;
    return 62.92 + 0.32217 * t + 0.005589 * t * t;
  }
  if (y >= 1986) {
    final t = y - 2000;
    return 63.86 + 0.3345 * t - 0.060374 * t * t + 0.0017275 * t * t * t +
        0.000651814 * t * t * t * t + 0.00002373599 * t * t * t * t * t;
  }
  if (y >= 1961) {
    final t = y - 1975;
    return 45.45 + 1.067 * t - t * t / 260 - t * t * t / 718;
  }
  if (y >= 1941) {
    final t = y - 1950;
    return 29.07 + 0.407 * t - t * t / 233 + t * t * t / 2547;
  }
  if (y >= 1920) {
    final t = y - 1920;
    return 21.20 + 0.84493 * t - 0.076100 * t * t + 0.0020936 * t * t * t;
  }
  final t = y - 1900;
  return -2.79 + 1.494119 * t - 0.0598939 * t * t + 0.0061966 * t * t * t - 0.000197 * t * t * t * t;
}
