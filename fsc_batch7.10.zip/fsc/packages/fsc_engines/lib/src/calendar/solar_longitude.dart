import 'dart:math' as math;

import 'julian.dart';

/// 太陽視黃經計算(Meeus《Astronomical Algorithms》Ch.25 低精度法,
/// 精度約 0.01°≈15 分鐘)。用於節氣求解。
///
/// 精度策略(02 §2.4):App 正式節氣時刻以資料包 solar_terms 表為準
/// (高精度來源編譯+人工抽驗);本演算法為表外年份後援與交叉驗證。
double apparentSolarLongitude(double jdUt, int year) {
  final jde = jdUt + deltaTSeconds(year) / 86400; // UT→TT
  final t = (jde - 2451545.0) / 36525;

  final l0 = 280.46646 + 36000.76983 * t + 0.0003032 * t * t;
  final m = 357.52911 + 35999.05029 * t - 0.0001537 * t * t;
  final mr = m * math.pi / 180;

  final c = (1.914602 - 0.004817 * t - 0.000014 * t * t) * math.sin(mr) +
      (0.019993 - 0.000101 * t) * math.sin(2 * mr) +
      0.000289 * math.sin(3 * mr);

  final trueLong = l0 + c;
  final omega = (125.04 - 1934.136 * t) * math.pi / 180;
  final apparent = trueLong - 0.00569 - 0.00478 * math.sin(omega);
  return ((apparent % 360) + 360) % 360;
}

/// 求 [year] 年太陽視黃經到達 [targetLongitude](度)的 UTC 時刻。
/// 牛頓式迭代:太陽平均日行 ≈ 360/365.2422°。
DateTime solarTermInstantUtc(int year, int targetLongitude) {
  // 初值:以春分(3/21 前後)為錨粗估該黃經對應日期。
  final offsetDays = (((targetLongitude - 0) % 360) + 360) % 360 / 360 * 365.2422;
  var jd = jdnFromCivil(year, 3, 21).toDouble() + offsetDays;
  for (var i = 0; i < 6; i++) {
    final lon = apparentSolarLongitude(jd, year);
    var diff = targetLongitude - lon;
    while (diff > 180) diff -= 360;
    while (diff < -180) diff += 360;
    jd += diff * 365.2422 / 360;
  }
  var utc = utcFromJd(jd);
  // 收斂後若跑出 year(黃經一年循環的錨定歧義),平移一個回歸年修正。
  if (utc.year > year) {
    utc = utcFromJd(jd - 365.2422);
  } else if (utc.year < year) {
    utc = utcFromJd(jd + 365.2422);
  }
  return utc;
}
