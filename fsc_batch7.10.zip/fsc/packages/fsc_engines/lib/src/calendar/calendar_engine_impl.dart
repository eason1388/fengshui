import 'package:fsc_domain/fsc_domain.dart';

import 'julian.dart';
import 'solar_longitude.dart';

/// 曆法引擎預設實作。
///
/// 排盤依據(皆為子平通行法,01/03 待確認事項已定案):
/// * 年柱:立春為歲界(可切冬至);錨點 1984 甲子年。
/// * 月柱:節氣「節」為月界(立春→寅月…);月干用五虎遁。
/// * 日柱:錨點 2000-01-07 甲子日(JDN 2451551);23 時起換日(可切)。
/// * 時柱:時支兩小時一支;時干用五鼠遁。
final class DefaultCalendarEngine implements CalendarEngine {
  /// 建立引擎。
  const DefaultCalendarEngine();

  @override
  String get version => 'calendar-1.0.0';

  /// 日柱錨點:2000-01-07 = 甲子日。
  static const int _jdnJiaZi = 2451551;

  @override
  DateTime termInstant(int year, SolarTermType term) =>
      solarTermInstantUtc(year, term.longitude);

  @override
  SolarTermType currentTerm(DateTime utc) {
    final lon = apparentSolarLongitude(jdFromUtc(utc), utc.year);
    // 節氣按黃經每 15° 一段;lon 所在段的起點即當前節氣。
    final seg = (lon / 15).floor() * 15;
    return SolarTermType.values.firstWhere((t) => t.longitude == seg);
  }

  @override
  GanZhiDate fourPillars(
    DateTime local, {
    required int utcOffsetMinutes,
    YearBoundary yearBoundary = YearBoundary.liChun,
    LateZiRule lateZi = LateZiRule.nextDay,
    bool hourUncertain = false,
  }) {
    final utc = DateTime.utc(local.year, local.month, local.day, local.hour,
            local.minute, local.second)
        .subtract(Duration(minutes: utcOffsetMinutes));

    // ── 日柱(依當地民用日;晚子時規則) ─────────────────────────
    var civil = DateTime(local.year, local.month, local.day);
    if (lateZi == LateZiRule.nextDay && local.hour >= 23) {
      civil = civil.add(const Duration(days: 1));
    }
    final dayIndex =
        ((jdnFromCivil(civil.year, civil.month, civil.day) - _jdnJiaZi) % 60 + 60) % 60;
    final day = GanZhi(dayIndex);

    // ── 年柱(歲界:立春/冬至之精確時刻) ────────────────────────
    final boundaryTerm =
        yearBoundary == YearBoundary.liChun ? SolarTermType.liChun : SolarTermType.dongZhi;
    var suiYear = utc.year;
    final boundary = termInstant(utc.year, boundaryTerm);
    if (utc.isBefore(boundary)) suiYear -= 1;
    final year = GanZhi(((suiYear - 1984) % 60 + 60) % 60);

    // ── 月柱(節氣月:立春=寅月起;五虎遁) ──────────────────────
    final lon = apparentSolarLongitude(jdFromUtc(utc), utc.year);
    final monthIndex = ((((lon - 315) % 360) + 360) % 360) ~/ 30; // 0=寅月
    final monthBranch = Branch.values[(monthIndex + 2) % 12];
    final monthStem =
        Stem.values[((year.stem.index % 5) * 2 + 2 + monthIndex) % 10];
    final month = GanZhi.of(monthStem, monthBranch);

    // ── 時柱(五鼠遁) ───────────────────────────────────────────
    final hourBranchIndex = ((local.hour + 1) ~/ 2) % 12;
    final hourBranch = Branch.values[hourBranchIndex];
    final hourStem =
        Stem.values[((day.stem.index % 5) * 2 + hourBranchIndex) % 10];
    final hour = GanZhi.of(hourStem, hourBranch);

    return GanZhiDate(
      year: year,
      month: month,
      day: day,
      hour: hour,
      hourUncertain: hourUncertain,
    );
  }
}
