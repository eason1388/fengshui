import 'dart:math' as math;

/// 剖面特徵點。
enum TerrainFeature {
  /// 峰(起)。
  peak('峰'),
  /// 過峽(束氣之處,鞍部)。
  pass('過峽'),
  /// 平段。
  flat('平');

  const TerrainFeature(this.zh);

  /// 中文。
  final String zh;
}

/// 特徵點。
final class ProfilePoint {
  /// 建立。
  const ProfilePoint({required this.index, required this.elevation, required this.feature});

  /// 樣本序。
  final int index;

  /// 高程(m)。
  final double elevation;

  /// 特徵。
  final TerrainFeature feature;
}

/// 龍脈剖面分析(FR-F6 地理尋龍之量化輔助;
/// 「起伏有致、過峽束氣」為佳,一路平坦或崩落為劣——巒頭派通則)。
final class DragonTerrainAnalyzer {
  /// 建立。[prominenceM] 起算峰/峽之最小落差。
  const DragonTerrainAnalyzer({this.prominenceM = 8});

  /// 顯著度門檻(公尺)。
  final double prominenceM;

  /// 版本。
  String get version => 'dragon-1.0.0';

  /// 偵測峰與過峽(鞍部)。輸入沿龍脈線之等距高程樣本。
  List<ProfilePoint> detect(List<double> elev) {
    final out = <ProfilePoint>[];
    if (elev.length < 3) return out;
    // 先平滑(3點移動平均)再找局部極值,顯著度過濾。
    final sm = List<double>.generate(
        elev.length,
        (i) => i == 0 || i == elev.length - 1
            ? elev[i]
            : (elev[i - 1] + elev[i] + elev[i + 1]) / 3);
    for (var i = 1; i < sm.length - 1; i++) {
      final isMax = sm[i] > sm[i - 1] && sm[i] >= sm[i + 1];
      final isMin = sm[i] < sm[i - 1] && sm[i] <= sm[i + 1];
      if (!isMax && !isMin) continue;
      // 顯著度:向兩側走到首個反向越過點,取途中之極值落差
      double extL = sm[i], extR = sm[i];
      for (var l = i - 1; l >= 0 && (isMax ? sm[l] < sm[i] : sm[l] > sm[i]); l--) {
        extL = isMax ? math.min(extL, sm[l]) : math.max(extL, sm[l]);
      }
      for (var r = i + 1;
          r < sm.length && (isMax ? sm[r] < sm[i] : sm[r] > sm[i]);
          r++) {
        extR = isMax ? math.min(extR, sm[r]) : math.max(extR, sm[r]);
      }
      final prom = isMax
          ? sm[i] - math.max(extL, extR)
          : math.min(extL, extR) - sm[i];
      if (prom >= prominenceM) {
        out.add(ProfilePoint(
            index: i,
            elevation: elev[i],
            feature: isMax ? TerrainFeature.peak : TerrainFeature.pass));
      }
    }
    return out;
  }

  /// 龍脈品質 0–100:
  /// 起伏節數(峰+峽對數)越多越佳(每對+15,上限60)、
  /// 總落差適中(50–500m 佳)+20、末段下降(結穴前緩降)+20。
  ({int score, List<String> notes}) quality(List<double> elev) {
    final feats = detect(elev);
    final peaks = feats.where((f) => f.feature == TerrainFeature.peak).length;
    final passes = feats.where((f) => f.feature == TerrainFeature.pass).length;
    final pairs = math.min(peaks, passes);
    var score = math.min(60, pairs * 15);
    final notes = <String>['起伏節數:$peaks 峰 $passes 峽'];
    final drop = elev.reduce(math.max) - elev.reduce(math.min);
    if (drop >= 50 && drop <= 500) {
      score += 20;
      notes.add('總落差 ${drop.toStringAsFixed(0)}m,適中');
    } else {
      notes.add('總落差 ${drop.toStringAsFixed(0)}m,${drop < 50 ? '過平(氣弱)' : '過險(氣急)'}');
    }
    final tail = elev.length ~/ 5;
    if (elev.last < elev[elev.length - 1 - tail]) {
      score += 20;
      notes.add('末段緩降,有結穴之勢');
    } else {
      notes.add('末段未見緩降');
    }
    return (score: score.clamp(0, 100), notes: notes);
  }
}
