import 'dart:math' as math;

import 'package:fsc_domain/fsc_domain.dart';

/// 平面座標點(公尺或像素,任意一致單位)。
typedef XY = ({double x, double y});

/// 房間(多邊形+用途)。
final class RoomShape {
  /// 建立。
  const RoomShape({required this.id, required this.polygon, required this.kind});

  /// 識別。
  final String id;

  /// 頂點(≥3)。
  final List<XY> polygon;

  /// door/bedroom/kitchen/desk/cashier…(02 §3.2 rooms)。
  final String kind;
}

/// 房間落宮結果。
final class RoomPalace {
  /// 建立。
  const RoomPalace({required this.room, required this.palace, required this.coverage});

  /// 房間。
  final RoomShape room;

  /// 主落宮(面積佔比最大)。
  final Palace palace;

  /// 佔比(0–1;<0.5 表跨宮,UI 應提示)。
  final double coverage;
}

/// 九宮映射引擎(立極八分法):
/// 宮位由「該點自立極點之實際羅盤方位」決定——坎=北、離=南…與宅之坐向無關;
/// 中宮=宅外接框中央三分之一區。井字三等分法為另一派做法,留門派設定(pending)。
/// 拍照 AI 辨識(V3)輸出牆體多邊形後即接本引擎;手動描圖走同一路徑。
final class NinePalaceMapper {
  /// 建立。
  const NinePalaceMapper();

  /// 版本。
  String get version => 'ninepalace-1.1.0';

  /// 將房間映射到九宮。
  /// [jiJi] 立極點(平面座標,y 向下);
  /// [northDeg] 平面圖「上方」的真北方位角(地圖描圖=0;拍照平面圖由使用者標北);
  /// [halfWidth]/[halfHeight] 宅外接框半寬高(定中宮範圍)。
  List<RoomPalace> map({
    required List<RoomShape> rooms,
    required XY jiJi,
    required double northDeg,
    required double halfWidth,
    required double halfHeight,
  }) {
    Palace palaceOf(XY p) {
      final dx = p.x - jiJi.x, dy = p.y - jiJi.y;
      if (dx.abs() <= halfWidth / 3 && dy.abs() <= halfHeight / 3) {
        return Palace.center5;
      }
      // 平面方位(上=northDeg):atan2(dx, -dy) 為相對「上」之角
      final bearing =
          ((math.atan2(dx, -dy) * 180 / math.pi) + northDeg + 360) % 360;
      const order = [
        Palace.kan1, Palace.gen8, Palace.zhen3, Palace.xun4,
        Palace.li9, Palace.kun2, Palace.dui7, Palace.qian6,
      ];
      return order[(((bearing + 22.5) % 360) ~/ 45)];
    }

    return rooms.map((r) {
      final counts = <Palace, int>{};
      var total = 0;
      final xs = r.polygon.map((p) => p.x);
      final ys = r.polygon.map((p) => p.y);
      final minX = xs.reduce(math.min), maxX = xs.reduce(math.max);
      final minY = ys.reduce(math.min), maxY = ys.reduce(math.max);
      for (var i = 0; i < 8; i++) {
        for (var j = 0; j < 8; j++) {
          final p = (
            x: minX + (maxX - minX) * (i + .5) / 8,
            y: minY + (maxY - minY) * (j + .5) / 8,
          );
          if (!_inside(p, r.polygon)) continue;
          total++;
          final pal = palaceOf(p);
          counts[pal] = (counts[pal] ?? 0) + 1;
        }
      }
      final best = counts.entries.reduce((a, b) => a.value >= b.value ? a : b);
      return RoomPalace(
        room: r,
        palace: best.key,
        coverage: total == 0 ? 0 : best.value / total,
      );
    }).toList();
  }

  bool _inside(XY p, List<XY> poly) {
    var inside = false;
    for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      if ((poly[i].y > p.y) != (poly[j].y > p.y) &&
          p.x <
              (poly[j].x - poly[i].x) * (p.y - poly[i].y) /
                      (poly[j].y - poly[i].y) +
                  poly[i].x) {
        inside = !inside;
      }
    }
    return inside;
  }
}
