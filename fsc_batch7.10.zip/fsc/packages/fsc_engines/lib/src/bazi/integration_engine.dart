import 'package:fsc_domain/fsc_domain.dart';

/// 評分項(可解釋:每項附規則 id 與出處,FR-E2)。
final class ScoredItem {
  /// 建立。
  const ScoredItem({
    required this.ruleId,
    required this.titleKey,
    required this.delta,
    required this.sourceRef,
  });

  /// 規則 id。
  final String ruleId;

  /// 標題 i18n key。
  final String titleKey;

  /// 加減分。
  final int delta;

  /// 典籍/口訣出處。
  final String sourceRef;
}

/// 整合結果。
final class IntegrationResult {
  /// 建立。
  const IntegrationResult({required this.score, required this.items});

  /// 總分 0–100。
  final int score;

  /// 逐項依據。
  final List<ScoredItem> items;
}

/// 八字×風水整合評分(v1 基準模型;權重屬門派包 scoring 規則,可覆寫)。
final class BaziFengShuiIntegrator {
  /// 建立。
  const BaziFengShuiIntegrator();

  /// 版本。
  String get version => 'integrate-1.0.0';

  /// 二十四山五行(正五行):支依 BWX、干依 WX、四維=土?
  /// 慣例:乾兌金、艮坤土、震巽木、坎水離火(卦五行)——四維山用卦五行。
  WuXing mountainWuXing(Mountain24 m) {
    const trigramWx = {
      Mountain24.qian: WuXing.metal, Mountain24.kun: WuXing.earth,
      Mountain24.gen: WuXing.earth, Mountain24.xun: WuXing.wood,
    };
    if (trigramWx.containsKey(m)) return trigramWx[m]!;
    const stems = {
      Mountain24.jia: WuXing.wood, Mountain24.yi: WuXing.wood,
      Mountain24.bing: WuXing.fire, Mountain24.ding: WuXing.fire,
      Mountain24.geng: WuXing.metal, Mountain24.xin: WuXing.metal,
      Mountain24.ren: WuXing.water, Mountain24.gui: WuXing.water,
    };
    if (stems.containsKey(m)) return stems[m]!;
    const branches = {
      Mountain24.zi: WuXing.water, Mountain24.chou: WuXing.earth,
      Mountain24.yin: WuXing.wood, Mountain24.mao: WuXing.wood,
      Mountain24.chen: WuXing.earth, Mountain24.si: WuXing.fire,
      Mountain24.wu: WuXing.fire, Mountain24.wei: WuXing.earth,
      Mountain24.shen: WuXing.metal, Mountain24.you: WuXing.metal,
      Mountain24.xu: WuXing.earth, Mountain24.hai: WuXing.water,
    };
    return branches[m]!;
  }

  /// 評分。
  IntegrationResult analyze({
    required BaziChart owner,
    required FlyingStarChart house,
    required BaZhaiChart baZhai,
  }) {
    final items = <ScoredItem>[];
    var score = 50;

    // 1. 玄空格局
    final patternDelta = switch (house.pattern) {
      ChartPattern.wangShanWangXiang => 25,
      ChartPattern.doubleAtFacing => 12,
      ChartPattern.doubleAtSitting => 10,
      ChartPattern.shangShanXiaShui => -20,
      ChartPattern.other => 0,
    };
    items.add(ScoredItem(
        ruleId: 'xk.pattern', titleKey: 'score.pattern.${house.pattern.name}',
        delta: patternDelta, sourceRef: '沈氏玄空學'));

    // 2. 坐山五行 × 喜用神
    final mw = mountainWuXing(house.sitting);
    final favor = owner.favorable.contains(mw);
    items.add(ScoredItem(
        ruleId: 'bz.sitting_wuxing',
        titleKey: favor ? 'score.sitting.favor' : 'score.sitting.neutral',
        delta: favor ? 15 : 0, sourceRef: '八字喜用神×正五行'));

    // 3. 忌神方(喜用之反)坐山=減分
    if (owner.favorable.isNotEmpty && !favor) {
      final avoid = WuXing.values[
          (owner.dayMaster.wuxing.index + (owner.strength.isWeak ? 3 : 4)) % 5];
      if (mw == avoid) {
        items.add(const ScoredItem(
            ruleId: 'bz.sitting_avoid', titleKey: 'score.sitting.avoid',
            delta: -10, sourceRef: '八字忌神×正五行'));
      }
    }

    // 4. 三般卦加分、伏吟反吟減分
    if (house.sanBan != null) {
      items.add(const ScoredItem(
          ruleId: 'xk.sanban', titleKey: 'score.sanban',
          delta: 8, sourceRef: '沈氏玄空學'));
    }
    for (final _ in house.warnings) {
      items.add(const ScoredItem(
          ruleId: 'xk.fuyin', titleKey: 'score.fuyin',
          delta: -12, sourceRef: '沈氏玄空學'));
    }

    // 5. 城門可用小幅加分
    if (house.gates.any((g) => g.usable)) {
      items.add(const ScoredItem(
          ruleId: 'xk.gate', titleKey: 'score.gate.usable',
          delta: 5, sourceRef: '城門訣'));
    }

    score += items.fold(0, (s, i) => s + i.delta);
    return IntegrationResult(score: score.clamp(0, 100), items: items);
  }
}
