import 'package:fsc_domain/fsc_domain.dart';

/// 八字引擎(v1)。
///
/// * 十神:以日主與他干之五行生剋+陰陽同異定名(固定表,已驗證)。
/// * 藏干:通行本氣/中氣/餘氣表,權重 0.6/0.3/0.1(午亥 0.7/0.3)。
/// * 強弱:透明計分——干(年月時各6)+支藏干(年8/月30/日12/時8×權重),
///   同黨(同我+生我)>55% 身強、<45% 身弱。權重屬 bazi_rules 資料,可調。
/// * 喜用:身弱喜印比;身強喜食傷/財/官殺;中和留調候(v2)。
/// * 大運:陽年男/陰年女順排;起運=距鄰近「節」日數÷3(年)。
final class DefaultBaziEngine {
  /// 需曆法引擎(四柱與節氣)。
  const DefaultBaziEngine(this.calendar);

  /// 曆法引擎。
  final CalendarEngine calendar;

  /// 引擎版本。
  String get version => 'bazi-1.0.0';

  /// 藏干表(干,權重)。
  static const hidden = <Branch, List<(Stem, double)>>{
    Branch.zi: [(Stem.gui, 1)],
    Branch.chou: [(Stem.ji, .6), (Stem.gui, .3), (Stem.xin, .1)],
    Branch.yin: [(Stem.jia, .6), (Stem.bing, .3), (Stem.wu, .1)],
    Branch.mao: [(Stem.yi, 1)],
    Branch.chen: [(Stem.wu, .6), (Stem.yi, .3), (Stem.gui, .1)],
    Branch.si: [(Stem.bing, .6), (Stem.geng, .3), (Stem.wu, .1)],
    Branch.wuma: [(Stem.ding, .7), (Stem.ji, .3)],
    Branch.wei: [(Stem.ji, .6), (Stem.ding, .3), (Stem.yi, .1)],
    Branch.shen: [(Stem.geng, .6), (Stem.ren, .3), (Stem.wu, .1)],
    Branch.you: [(Stem.xin, 1)],
    Branch.xu: [(Stem.wu, .6), (Stem.xin, .3), (Stem.ding, .1)],
    Branch.hai: [(Stem.ren, .7), (Stem.jia, .3)],
  };

  /// 十神。
  TenGod tenGod(Stem dayMaster, Stem other) {
    final rel = (other.wuxing.index - dayMaster.wuxing.index + 5) % 5;
    final same = dayMaster.index.isEven == other.index.isEven;
    return TenGod.values[rel * 2 + (same ? 0 : 1)];
  }

  /// 排盤。[daysToJie] 距鄰近節之日數(順排取未來節、逆排取過去節),
  /// 由呼叫方以 [calendar] 求得後傳入(保持本函數純粹可測)。
  BaziChart compute({
    required GanZhiDate pillars,
    required bool isMale,
    required double daysToJie,
  }) {
    final dm = pillars.day.stem;

    // 五行計分
    const stemW = {'year': 6.0, 'month': 6.0, 'hour': 6.0};
    const branchW = {'year': 8.0, 'month': 30.0, 'day': 12.0, 'hour': 8.0};
    final pts = {for (final w in WuXing.values) w: 0.0};
    final byName = {
      'year': pillars.year, 'month': pillars.month,
      'day': pillars.day, 'hour': pillars.hour,
    };
    byName.forEach((name, gz) {
      if (name != 'day') {
        pts[gz.stem.wuxing] = pts[gz.stem.wuxing]! + stemW[name]!;
      }
      for (final (hs, w) in hidden[gz.branch]!) {
        pts[hs.wuxing] = pts[hs.wuxing]! + branchW[name]! * w;
      }
    });
    final total = pts.values.reduce((a, b) => a + b);
    final mother = WuXing.values[(dm.wuxing.index - 1 + 5) % 5];
    final ratio = (pts[dm.wuxing]! + pts[mother]!) / total;
    final strength = WuXingStrength(
      points: pts,
      sameFactionRatio: ratio,
      verdict: ratio > 0.55
          ? 'strength.strong'
          : ratio < 0.45
              ? 'strength.weak'
              : 'strength.balanced',
    );
    final favorable = strength.isWeak
        ? [mother, dm.wuxing]
        : strength.isStrong
            ? [
                WuXing.values[(dm.wuxing.index + 1) % 5],
                WuXing.values[(dm.wuxing.index + 2) % 5],
                WuXing.values[(dm.wuxing.index + 3) % 5],
              ]
            : <WuXing>[];

    // 大運
    final yang = pillars.year.stem.index.isEven;
    final forward = yang == isMale;
    final startAge = daysToJie / 3;
    final daYun = List.generate(8, (k) {
      final idx = (pillars.month.index + (forward ? k + 1 : -(k + 1))) % 60;
      return DaYun(
          pillar: GanZhi((idx + 60) % 60), startAge: startAge + k * 10);
    });

    return BaziChart(
      pillars: pillars,
      dayMaster: dm,
      tenGods: {
        'year': tenGod(dm, pillars.year.stem),
        'month': tenGod(dm, pillars.month.stem),
        'hour': tenGod(dm, pillars.hour.stem),
      },
      strength: strength,
      favorable: favorable,
      daYun: daYun,
      forward: forward,
    );
  }
}
