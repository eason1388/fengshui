import 'package:fsc_domain/fsc_domain.dart';

import 'ring_tables.g.dart';

/// 判讀引擎預設實作。
///
/// 規則(01/03 已確認之預設,門派包可經 [TheoryConfig] 覆寫):
/// * 偏中線 ≤3° 為正向;>3° 為兼向;>4.5° 玄空須用替卦。
/// * 距山界 <1° 判「騎縫線」。
/// * 落戊己分金=「空亡線」;落甲乙壬癸分金=「差錯線」。
final class DefaultBearingInterpreter implements BearingInterpreter {
  /// 以內建資料表建立(資料包 OTA 後可注入新表)。
  const DefaultBearingInterpreter({
    this.fenJinTable = fenJin120,
    this.dragons72Table = dragons72,
    this.dragons60Table = dragons60,
  });

  /// 分金表。
  final RingTable fenJinTable;

  /// 七十二龍表。
  final RingTable dragons72Table;

  /// 六十龍表。
  final RingTable dragons60Table;

  @override
  String get version => 'bearing-1.0.0';

  @override
  BearingReading interpret(
    Azimuth az, {
    required bool isSitting,
    TheoryConfig config = const TheoryConfig(),
  }) {
    final a = az.normalized();
    final mountain = Mountain24.fromAzimuth(a);
    final sitting = isSitting ? mountain : mountain.opposite;
    final facing = sitting.opposite;

    // ── 兼向:相對山中線之有向偏移(順時針為正) ──────────────
    var lean = a.degrees - mountain.centerDeg;
    if (lean > 180) lean -= 360;
    if (lean < -180) lean += 360;
    final isPure = lean.abs() <= config.jianThresholdDeg;
    final neighbor = lean >= 0
        ? Mountain24.values[(mountain.index + 1) % 24]
        : Mountain24.values[(mountain.index + 23) % 24];
    final jian = JianXiang(
      isPure: isPure,
      leanTo: isPure ? null : (isSitting ? neighbor : neighbor.opposite),
      leanDeg: double.parse(lean.toStringAsFixed(2)),
      requiresTiGua: lean.abs() > config.tiGuaThresholdDeg,
    );

    // ── 各圈定位 ────────────────────────────────────────────
    final fj = fenJinTable.cellAt(a);
    final d72 = dragons72Table.cellAt(a);
    final d60 = dragons60Table.cellAt(a);

    // ── 凶線警告 ────────────────────────────────────────────
    final warnings = <LineWarning>[];
    final toBoundary = Mountain24.distanceToBoundary(a);
    if (toBoundary < config.qiFengThresholdDeg) {
      final boundary = lean >= 0 ? mountain.endDeg : mountain.startDeg;
      warnings.add(QiFengLine(boundary));
    }
    switch (fj.quality) {
      case FenJinQuality.kongWang:
        warnings.add(const KongWangLine());
      case FenJinQuality.gu || FenJinQuality.xu:
        warnings.add(const ChaCuoLine());
      case FenJinQuality.wang || FenJinQuality.xiang || null:
        break;
    }

    return BearingReading(
      azimuth: a,
      isSitting: isSitting,
      sitting: sitting,
      facing: facing,
      jian: jian,
      warnings: List.unmodifiable(warnings),
      fenJin: fj,
      dragon72: d72,
      dragon60: d60,
    );
  }
}
