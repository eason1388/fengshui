import 'package:fsc_domain/fsc_domain.dart';

import '../calendar/julian.dart';

/// 紫白飛星引擎(年/月/日/時,FR-C1–C3)。
///
/// 口訣依據(已驗證錨點:2024三碧/2025二黑/2026一白;
/// 五黃 2024西 2025東北 2026南):
/// * 年星:(11 − 歲年 mod 9) 合九;立春換年。
/// * 月星:子午卯酉年寅月八白、辰戌丑未年五黃、寅申巳亥年二黑,逐月遞減。
/// * 日星:三元遁——陽遁(冬至/雨水/穀雨後首甲子起 1/7/4 順行)、
///   陰遁(夏至/處暑/霜降後首甲子起 9/3/6 逆行)。各派略異,pending_expert。
/// * 時星:陽遁子午卯酉日子時起一白(辰戌丑未起四、寅申巳亥起七)順行;陰遁 9/6/3 逆行。
final class DefaultZiBaiEngine {
  /// 需曆法引擎提供節氣時刻。
  const DefaultZiBaiEngine(this.calendar);

  /// 曆法引擎。
  final CalendarEngine calendar;

  /// 引擎版本。
  String get version => 'zibai-1.0.0';

  static const _flyOrder = [
    Palace.center5, Palace.qian6, Palace.dui7, Palace.gen8, Palace.li9,
    Palace.kan1, Palace.kun2, Palace.zhen3, Palace.xun4,
  ];

  Map<Palace, int> _fly(int center, {bool forward = true}) {
    final out = <Palace, int>{};
    var s = center;
    for (final p in _flyOrder) {
      out[p] = s;
      s = forward ? s % 9 + 1 : (s - 2 + 9) % 9 + 1;
    }
    return out;
  }

  /// 年星入中(歲年,已過立春界)。
  int annualStar(int suiYear) => (11 - suiYear % 9 - 1) % 9 + 1;

  /// 年盤。
  Map<Palace, int> annual(int suiYear) => _fly(annualStar(suiYear));

  /// 月星入中([monthIndex] 0=寅月)。
  int monthStar(int suiYear, int monthIndex) {
    final b = ((suiYear - 4) % 12 + 12) % 12;
    const firstByBranch = [8, 5, 2, 8, 5, 2, 8, 5, 2, 8, 5, 2];
    return (firstByBranch[b] - 1 - monthIndex) % 9 + 1;
  }

  /// 月盤。
  Map<Palace, int> monthly(int suiYear, int monthIndex) =>
      _fly(monthStar(suiYear, monthIndex));

  /// 日星(UTC 之當地民用日以 jdn 表示;甲子錨 jdn%60==11)。
  /// [termAnchors]:六節氣錨(冬至/雨水/穀雨/夏至/處暑/霜降)之 (jdn, 起星, 順逆),
  /// 由呼叫方以 [calendar] 取當年與前一年節氣組裝、按時間新→舊排序。
  (int, bool) dailyStar(int jdn, List<(int, int, bool)> termAnchors) {
    for (final (tJdn, start, forward) in termAnchors) {
      final jiaZi = tJdn + ((-(tJdn - 11)) % 60 + 60) % 60; // 節後首甲子
      if (jdn >= jiaZi) {
        final d = jdn - jiaZi;
        final star = ((start - 1) + (forward ? d : -d)) % 9;
        return ((star + 9) % 9 + 1, forward);
      }
    }
    throw StateError('termAnchors 不足,需涵蓋前一年冬至');
  }

  /// 時星。[dayBranch] 日支、[hourIndex] 0=子時、[yangDun] 陽遁?
  int hourStar(Branch dayBranch, int hourIndex, {required bool yangDun}) {
    const group = [0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2];
    final g = group[dayBranch.index];
    final start = yangDun ? const [1, 4, 7][g] : const [9, 6, 3][g];
    final s = ((start - 1) + (yangDun ? hourIndex : -hourIndex)) % 9;
    return (s + 9) % 9 + 1;
  }
}
