import 'package:fsc_domain/fsc_domain.dart';

import 'zibai_engine_impl.dart';

/// 年神煞與個人吉位引擎(FR-C4/C5)。口訣皆為通行固定表。
final class DefaultShenShaEngine {
  /// 建立。
  const DefaultShenShaEngine(this.ziBai);

  /// 紫白引擎(取五黃)。
  final DefaultZiBaiEngine ziBai;

  /// 引擎版本。
  String get version => 'shensha-1.0.0';

  /// 年神煞。[suiYear] 歲年(立春界)。
  AnnualShenSha annual(int suiYear) {
    final b = ((suiYear - 4) % 12 + 12) % 12;
    final taiSui = Branch.values[b];
    final suiPo = Branch.values[(b + 6) % 12];
    // 三合局煞方:申子辰煞南、寅午戌煞北、巳酉丑煞東、亥卯未煞西。
    const shaByGroup = {
      0: [Branch.si, Branch.wuma, Branch.wei],
      1: [Branch.hai, Branch.zi, Branch.chou],
      2: [Branch.yin, Branch.mao, Branch.chen],
      3: [Branch.shen, Branch.you, Branch.xu],
    };
    final group = switch (b) {
      8 || 0 || 4 => 0, // 申子辰
      2 || 6 || 10 => 1, // 寅午戌
      5 || 9 || 1 => 2, // 巳酉丑
      _ => 3, // 亥卯未
    };
    final wuHuang = ziBai
        .annual(suiYear)
        .entries
        .firstWhere((e) => e.value == 5)
        .key;
    return AnnualShenSha(
      suiYear: suiYear,
      taiSui: taiSui,
      suiPo: suiPo,
      sanSha: shaByGroup[group]!,
      wuHuang: wuHuang,
    );
  }

  /// 個人吉位(依出生歲年干支)。
  PersonalPositions personal(GanZhi yearPillar) {
    const wenChang = {
      Stem.jia: Branch.si, Stem.yi: Branch.wuma,
      Stem.bing: Branch.shen, Stem.wu: Branch.shen,
      Stem.ding: Branch.you, Stem.ji: Branch.you,
      Stem.geng: Branch.hai, Stem.xin: Branch.zi,
      Stem.ren: Branch.yin, Stem.gui: Branch.mao,
    };
    const guiRen = {
      Stem.jia: [Branch.chou, Branch.wei], Stem.wu: [Branch.chou, Branch.wei],
      Stem.geng: [Branch.chou, Branch.wei],
      Stem.yi: [Branch.zi, Branch.shen], Stem.ji: [Branch.zi, Branch.shen],
      Stem.bing: [Branch.hai, Branch.you], Stem.ding: [Branch.hai, Branch.you],
      Stem.ren: [Branch.si, Branch.mao], Stem.gui: [Branch.si, Branch.mao],
      Stem.xin: [Branch.wuma, Branch.yin],
    };
    // 三合局:桃花(咸池)與驛馬。
    const taoHua = [Branch.you, Branch.wuma, Branch.mao, Branch.zi];
    const yiMa = [Branch.yin, Branch.hai, Branch.shen, Branch.si];
    final g = switch (yearPillar.branch.index) {
      8 || 0 || 4 => 0, 5 || 9 || 1 => 1, 2 || 6 || 10 => 2, _ => 3,
    };
    return PersonalPositions(
      wenChang: wenChang[yearPillar.stem]!,
      taoHua: taoHua[g],
      yiMa: yiMa[g],
      guiRen: guiRen[yearPillar.stem]!,
    );
  }
}
