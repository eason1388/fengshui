import 'package:fsc_domain/fsc_domain.dart';

/// 八宅引擎。
///
/// 遊星以卦爻 XOR 求得(與大遊年歌 64 組全等,經驗證):
/// 兩卦三爻互異之處決定遊星。命卦公式:年數合成單數 s,
/// 男=11−s、女=s+4(再合成單數;5 寄:男坤女艮)。歲界=立春。
final class DefaultBaZhaiEngine {
  /// 建立。
  const DefaultBaZhaiEngine();

  /// 引擎版本。
  String get version => 'bazhai-1.0.0';

  /// 卦→三爻二進位(下中上)。
  static const _bin = {
    Trigram.qian: 7, Trigram.dui: 6, Trigram.li: 5, Trigram.zhen: 4,
    Trigram.xun: 3, Trigram.kan: 2, Trigram.gen: 1, Trigram.kun: 0,
  };

  /// XOR → 遊星(000 伏位…111 延年)。
  static const _star = [
    WanderingStar.fuWei, WanderingStar.shengQi, WanderingStar.jueMing,
    WanderingStar.wuGui, WanderingStar.huoHai, WanderingStar.liuSha,
    WanderingStar.tianYi, WanderingStar.yanNian,
  ];

  /// 宅卦:坐山所屬卦宮。
  Trigram houseGua(Mountain24 sitting) => switch (sitting.palace) {
        Palace.kan1 => Trigram.kan,
        Palace.kun2 => Trigram.kun,
        Palace.zhen3 => Trigram.zhen,
        Palace.xun4 => Trigram.xun,
        Palace.qian6 => Trigram.qian,
        Palace.dui7 => Trigram.dui,
        Palace.gen8 => Trigram.gen,
        Palace.li9 => Trigram.li,
        Palace.center5 => throw StateError('unreachable'),
      };

  /// 命卦(年須先經立春歲界修正)。
  Trigram mingGua({required int suiYear, required bool isMale}) {
    int digitSum(int n) => n < 10 ? n : digitSum(n ~/ 10 + n % 10);
    final s = digitSum(suiYear);
    var g = isMale ? digitSum(11 - s == 0 ? 9 : 11 - s) : digitSum(s + 4);
    if (g == 5) g = isMale ? 2 : 8; // 五寄:男坤女艮
    const byNum = {
      1: Trigram.kan, 2: Trigram.kun, 3: Trigram.zhen, 4: Trigram.xun,
      6: Trigram.qian, 7: Trigram.dui, 8: Trigram.gen, 9: Trigram.li,
    };
    return byNum[g]!;
  }

  /// 排八宅盤。
  BaZhaiChart chart(Trigram gua) => BaZhaiChart(
        gua: gua,
        byGong: {
          for (final g in Trigram.values) g: _star[_bin[gua]! ^ _bin[g]!],
        },
      );
}
