/// fsc_sensors:方位量測演算法(純 Dart,可完整單元測試)。
/// 平台感測器(sensors_plus 等)之接線在 app 層 adapter 完成。
library fsc_sensors;

export 'src/calibration.dart';
export 'src/declination.dart';
export 'src/fusion.dart';
export 'src/geodesy.dart';
export 'src/tilt_compass.dart';
