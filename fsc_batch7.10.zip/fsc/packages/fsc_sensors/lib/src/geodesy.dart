import 'dart:math' as math;

/// 經緯度點(WGS84,度)。
final class GeoPoint {
  /// 建立。
  const GeoPoint(this.lat, this.lon);

  /// 緯度。
  final double lat;

  /// 經度。
  final double lon;
}

double _rad(double d) => d * math.pi / 180;
double _deg(double r) => r * 180 / math.pi;

/// 兩點間大圓初始方位角(0–360,自北順時針)——地圖兩點測向(FR-D2)。
double initialBearingDeg(GeoPoint a, GeoPoint b) {
  final f1 = _rad(a.lat), f2 = _rad(b.lat), dl = _rad(b.lon - a.lon);
  final y = math.sin(dl) * math.cos(f2);
  final x = math.cos(f1) * math.sin(f2) -
      math.sin(f1) * math.cos(f2) * math.cos(dl);
  return (_deg(math.atan2(y, x)) + 360) % 360;
}

/// 建物輪廓形心(立極點)。等距圓柱局部投影+多邊形形心公式;
/// 建物尺度(<1km)下誤差可忽略。頂點需 ≥3。
GeoPoint polygonCentroid(List<GeoPoint> pts) {
  assert(pts.length >= 3, '需至少三個頂點');
  final lat0 = pts.first.lat;
  final k = math.cos(_rad(lat0));
  final xy = [for (final p in pts) (x: p.lon * k, y: p.lat)];
  var a = 0.0, cx = 0.0, cy = 0.0;
  for (var i = 0; i < xy.length; i++) {
    final p = xy[i], q = xy[(i + 1) % xy.length];
    final cr = p.x * q.y - q.x * p.y;
    a += cr;
    cx += (p.x + q.x) * cr;
    cy += (p.y + q.y) * cr;
  }
  a /= 2;
  if (a.abs() < 1e-12) {
    // 退化(共線):退回頂點平均。
    final mlat = pts.map((p) => p.lat).reduce((x, y) => x + y) / pts.length;
    final mlon = pts.map((p) => p.lon).reduce((x, y) => x + y) / pts.length;
    return GeoPoint(mlat, mlon);
  }
  return GeoPoint(cy / (6 * a), cx / (6 * a) / k);
}

/// 兩方位角最短夾角(0–180)——量角度工具(FR-D2)。
double angleBetweenDeg(double a, double b) {
  final d = (a - b).abs() % 360;
  return d > 180 ? 360 - d : d;
}
