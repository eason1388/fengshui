/// 磁偏角提供者(磁北→真北;東偏為正)。
///
/// 正式版:WMM(世界磁場模型)係數檔實作(資料包隨附 .COF,
/// 5 年一版,2025–2030 現行);離線可用。此處先定義介面與
/// 手動輸入實作,WMM 實作於 7.6b 併入資料包管線。
abstract interface class DeclinationProvider {
  /// 取磁偏角(度,東偏正)。[lat]/[lon] WGS84,[when] 時刻。
  double declinationDeg({
    required double lat,
    required double lon,
    required DateTime when,
  });
}

/// 手動磁偏角(使用者輸入或離線後援)。
final class ManualDeclination implements DeclinationProvider {
  /// 建立。
  const ManualDeclination(this.valueDeg);

  /// 固定值。
  final double valueDeg;

  @override
  double declinationDeg({
    required double lat,
    required double lon,
    required DateTime when,
  }) =>
      valueDeg;
}
