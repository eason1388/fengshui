import 'dart:collection';
import 'dart:math' as math;

import 'tilt_compass.dart';

/// 圓角插值:自 [a] 往 [b] 走比例 [t](處理 359→1 跨界)。
double circularLerp(double a, double b, double t) {
  var d = (b - a + 540) % 360 - 180;
  return (a + d * t + 360) % 360;
}

/// 圓角標準差(度)——抖動評估。
double circularStdDeg(Iterable<double> degs) {
  var s = 0.0, c = 0.0;
  var n = 0;
  for (final d in degs) {
    s += math.sin(d * math.pi / 180);
    c += math.cos(d * math.pi / 180);
    n++;
  }
  if (n == 0) return 0;
  final r = math.sqrt(s * s + c * c) / n;
  return math.sqrt(-2 * math.log(r.clamp(1e-12, 1.0))) * 180 / math.pi;
}

/// 互補濾波:陀螺儀短期積分(平滑)+ 磁力計長期校正(不漂移)。
/// gyro 權重 [gyroWeight] 預設 0.95(05 感測策略)。
final class HeadingFusion {
  /// 建立。
  HeadingFusion({this.gyroWeight = 0.95, this.jitterWindow = 30});

  /// 陀螺儀權重。
  final double gyroWeight;

  /// 抖動評估視窗(樣本數)。
  final int jitterWindow;

  double? _heading;
  final Queue<double> _recent = Queue();

  /// 目前融合方位(尚無樣本為 null)。
  double? get heading => _heading;

  /// 進一筆:[gyroZRadPerS] 繞垂直軸角速度(右手系,rad/s)、[dt] 秒、
  /// [magReading] 傾斜補償磁方位。回傳融合方位(度)。
  double update({
    required double gyroZRadPerS,
    required double dt,
    required TiltCompassReading magReading,
  }) {
    final magH = magReading.magneticHeadingDeg;
    if (_heading == null) {
      _heading = magH;
    } else {
      // 陀螺儀:z 軸朝上,裝置順時針轉(方位增加)= 負角速度。
      final gyroH = (_heading! - gyroZRadPerS * dt * 180 / math.pi + 360) % 360;
      _heading = circularLerp(magH, gyroH, gyroWeight);
    }
    _recent.addLast(_heading!);
    while (_recent.length > jitterWindow) {
      _recent.removeFirst();
    }
    return _heading!;
  }

  /// 抖動(圓角標準差,度)。供精度指示器降級用:>2° 降中、>5° 降低。
  double get jitterDeg => circularStdDeg(_recent);
}
