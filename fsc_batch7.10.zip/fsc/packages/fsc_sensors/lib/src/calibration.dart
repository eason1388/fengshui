import 'tilt_compass.dart';

/// 8 字校正會話:以「方位角×傾角」bin 覆蓋率估計校正進度,
/// 並蒐集場強樣本檢測硬鐵/干擾(01 FR-D1 校正模式)。
final class CalibrationSession {
  /// [azimuthBins]×[tiltBins] 個 bin,全覆蓋即完成。
  CalibrationSession({this.azimuthBins = 12, this.tiltBins = 3});

  /// 方位 bin 數。
  final int azimuthBins;

  /// 傾角 bin 數。
  final int tiltBins;

  final Set<int> _covered = {};
  final List<double> _fields = [];

  /// 進一筆樣本。
  void add(TiltCompassReading r) {
    final a = (r.magneticHeadingDeg / (360 / azimuthBins)).floor() % azimuthBins;
    final t = (r.tiltDeg / (90 / tiltBins)).floor().clamp(0, tiltBins - 1);
    _covered.add(a * tiltBins + t);
    _fields.add(r.fieldMicroTesla);
  }

  /// 進度 0–1。
  double get progress => _covered.length / (azimuthBins * tiltBins);

  /// 完成?
  bool get isComplete => progress >= 1;

  /// 場強變異過大(>±15 µT)→ 環境有移動磁源,提示換地點。
  bool get environmentUnstable {
    if (_fields.length < 10) return false;
    final mn = _fields.reduce((a, b) => a < b ? a : b);
    final mx = _fields.reduce((a, b) => a > b ? a : b);
    return mx - mn > 30;
  }
}
