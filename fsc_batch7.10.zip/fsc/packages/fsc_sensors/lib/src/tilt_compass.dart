import 'dart:math' as math;

/// 三維向量(最小實作,避免外部依賴)。
final class Vec3 {
  /// 建立。
  const Vec3(this.x, this.y, this.z);

  /// 分量。
  final double x, y, z;

  /// 內積。
  double dot(Vec3 o) => x * o.x + y * o.y + z * o.z;

  /// 外積。
  Vec3 cross(Vec3 o) =>
      Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x);

  /// 長度。
  double get norm => math.sqrt(dot(this));

  /// 單位化。
  Vec3 get unit => norm == 0 ? this : Vec3(x / norm, y / norm, z / norm);

  /// 減法。
  Vec3 operator -(Vec3 o) => Vec3(x - o.x, y - o.y, z - o.z);

  /// 純量乘。
  Vec3 scale(double k) => Vec3(x * k, y * k, z * k);
}

/// 量測品質等級(低精度時 UI 禁止出分析,NFR)。
enum SensorAccuracy {
  /// 高(可出具判讀)。
  high,

  /// 中(顯示但加註)。
  medium,

  /// 低(拒絕判讀)。
  low,
}

/// 傾斜補償羅盤讀數。
final class TiltCompassReading {
  /// 建立。
  const TiltCompassReading({
    required this.magneticHeadingDeg,
    required this.tiltDeg,
    required this.fieldMicroTesla,
    required this.accuracy,
    required this.interference,
  });

  /// 磁北方位角(0–360,順時針;真北=+磁偏角,由上層加)。
  final double magneticHeadingDeg;

  /// 裝置傾角(0=水平)。
  final double tiltDeg;

  /// 磁場強度(µT)。
  final double fieldMicroTesla;

  /// 精度等級。
  final SensorAccuracy accuracy;

  /// 疑似磁干擾(場強異常)。
  final bool interference;
}

/// 傾斜補償羅盤(向量投影法,與軸向慣例無關,較歐拉角法穩健):
/// 1. 由加速度計估重力方向 ĝ(裝置座標)。
/// 2. 將磁向量 m 與裝置 y 軸(機頂)投影到水平面。
/// 3. 方位角 = atan2((ŷₕ×m̂ₕ)·ĝ, ŷₕ·m̂ₕ)。
///
/// 地磁場強度正常範圍 25–65 µT;超界判干擾(01 FR-D1)。
TiltCompassReading tiltCompensatedHeading({
  required Vec3 accel, // 含重力反作用(裝置平放螢幕朝上 ≈ (0,0,+g))
  required Vec3 mag, // µT
}) {
  final g = accel.unit;
  const deviceY = Vec3(0, 1, 0);
  Vec3 horiz(Vec3 v) => v - g.scale(v.dot(g));
  final yh = horiz(deviceY);
  final mh = horiz(mag);

  final tilt = math.acos(g.dot(const Vec3(0, 0, 1)).clamp(-1, 1)) * 180 / math.pi;
  final field = mag.norm;
  final interference = field < 25 || field > 65;

  double heading;
  var degenerate = false;
  if (yh.norm < 1e-6 || mh.norm < 1e-6) {
    degenerate = true; // 機頂幾乎垂直向下/上,方位無定義
    heading = 0;
  } else {
    final s = yh.unit.cross(mh.unit).dot(g);
    final c = yh.unit.dot(mh.unit);
    heading = (math.atan2(s, c) * 180 / math.pi + 360) % 360;
  }

  final accuracy = degenerate || interference
      ? SensorAccuracy.low
      : tilt > 45
          ? SensorAccuracy.medium
          : SensorAccuracy.high;

  return TiltCompassReading(
    magneticHeadingDeg: heading,
    tiltDeg: tilt,
    fieldMicroTesla: field,
    accuracy: accuracy,
    interference: interference,
  );
}
