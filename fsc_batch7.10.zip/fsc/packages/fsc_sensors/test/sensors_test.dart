import 'dart:math' as math;

import 'package:fsc_sensors/fsc_sensors.dart';
import 'package:test/test.dart';

/// 以世界座標構造感測輸入:裝置平放,機頂朝方位 h;
/// 地磁場=水平 H 指北+垂直 V 向下(北半球)。
({Vec3 accel, Vec3 mag}) synth(double headingDeg, {double hField = 40, double vField = 30}) {
  final h = headingDeg * math.pi / 180;
  // 裝置座標:x 右、y 機頂、z 出螢幕。機頂朝 h → 北在裝置座標=(−sin h 於 x? 推導:
  // 世界北向量投影到裝置軸:x̂=(sin(h+90°)…) 直接旋轉:mx=−H sin h? 驗證 h=90(朝東):北=裝置−x → mx=−H ✓
  final mx = -hField * math.sin(h);
  final my = hField * math.cos(h);
  return (accel: const Vec3(0, 0, 9.81), mag: Vec3(mx, my, -vField));
}

void main() {
  group('傾斜補償羅盤(向量法)', () {
    test('平放四正方位', () {
      for (final h in [0.0, 90.0, 180.0, 270.0, 37.5, 278.0]) {
        final s = synth(h);
        final r = tiltCompensatedHeading(accel: s.accel, mag: s.mag);
        expect(r.magneticHeadingDeg, closeTo(h, 0.01), reason: '$h°');
        expect(r.accuracy, SensorAccuracy.high);
      }
    });
    test('前傾 30° 仍讀正確(傾斜補償)', () {
      // 繞裝置 x 軸前傾 30°:世界向量以 Rx(-30°) 轉入裝置座標。
      const t = -30 * math.pi / 180;
      Vec3 rx(Vec3 v) => Vec3(
          v.x, v.y * math.cos(t) - v.z * math.sin(t), v.y * math.sin(t) + v.z * math.cos(t));
      final s = synth(65);
      final r = tiltCompensatedHeading(accel: rx(s.accel), mag: rx(s.mag));
      expect(r.magneticHeadingDeg, closeTo(65, 0.01));
      expect(r.tiltDeg, closeTo(30, 0.1));
    });
    test('場強異常=干擾+低精度', () {
      final r = tiltCompensatedHeading(
          accel: const Vec3(0, 0, 9.81), mag: const Vec3(0, 120, -30));
      expect(r.interference, isTrue);
      expect(r.accuracy, SensorAccuracy.low);
    });
  });

  group('互補濾波', () {
    test('圓角插值跨 0°', () {
      expect(circularLerp(350, 10, 0.5), closeTo(0, 1e-9));
    });
    test('靜止時收斂到磁方位;抖動可量測', () {
      final f = HeadingFusion(gyroWeight: 0.9);
      final s = synth(120);
      final m = tiltCompensatedHeading(accel: s.accel, mag: s.mag);
      double h = 0;
      for (var i = 0; i < 200; i++) {
        h = f.update(gyroZRadPerS: 0, dt: 1 / 60, magReading: m);
      }
      expect(h, closeTo(120, 0.5));
      expect(f.jitterDeg, lessThan(1));
    });
    test('旋轉時陀螺儀主導平滑', () {
      final f = HeadingFusion();
      final s = synth(0);
      final m = tiltCompensatedHeading(accel: s.accel, mag: s.mag);
      f.update(gyroZRadPerS: 0, dt: 1 / 60, magReading: m);
      // 順時針轉(方位增加)=gyroZ 負(z 朝上右手系)
      final h = f.update(
          gyroZRadPerS: -math.pi / 2, dt: 1 / 60, magReading: m);
      expect(h, greaterThan(0)); // 朝增加方向移動,但被磁力計拉回部分
      expect(h, lessThan(1.5));
    });
  });

  group('校正會話', () {
    test('全方位掃過即完成;場強跳動=環境不穩', () {
      final c = CalibrationSession(azimuthBins: 12, tiltBins: 3);
      for (var a = 0; a < 360; a += 10) {
        for (final t in [10.0, 40.0, 70.0]) {
          c.add(TiltCompassReading(
            magneticHeadingDeg: a.toDouble(), tiltDeg: t,
            fieldMicroTesla: 45, accuracy: SensorAccuracy.high,
            interference: false,
          ));
        }
      }
      expect(c.isComplete, isTrue);
      expect(c.environmentUnstable, isFalse);
    });
  });

  group('大地測量', () {
    test('赤道正東/正北', () {
      expect(initialBearingDeg(const GeoPoint(0, 0), const GeoPoint(0, 1)),
          closeTo(90, 1e-6));
      expect(initialBearingDeg(const GeoPoint(0, 0), const GeoPoint(1, 0)),
          closeTo(0, 1e-6));
    });
    test('台北→高雄 約西南偏南', () {
      final b = initialBearingDeg(
          const GeoPoint(25.033, 121.565), const GeoPoint(22.627, 120.301));
      expect(b, inInclusiveRange(200, 210));
    });
    test('矩形形心', () {
      final c = polygonCentroid(const [
        GeoPoint(25.0, 121.0), GeoPoint(25.0, 121.001),
        GeoPoint(25.001, 121.001), GeoPoint(25.001, 121.0),
      ]);
      expect(c.lat, closeTo(25.0005, 1e-9));
      expect(c.lon, closeTo(121.0005, 1e-7));
    });
    test('夾角', () {
      expect(angleBetweenDeg(350, 10), 20);
    });
  });
}
