import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_luopan/fsc_luopan.dart';
import 'package:test/test.dart';

void main() {
  const table = RingTable(code: 'demo', anchorDeg: 0, span: 90, cells: [
    RingCell(index: 0, startDeg: 0, endDeg: 90, name: 'A'),
    RingCell(index: 1, startDeg: 90, endDeg: 180, name: 'B'),
    RingCell(index: 2, startDeg: 180, endDeg: 270, name: 'C'),
    RingCell(index: 3, startDeg: 270, endDeg: 360, name: 'D'),
  ]);
  const spec = RingVisualSpec(
      table: table, innerRadius: .5, outerRadius: .8, labelFontScale: .04);

  test('極座標命中:半徑帶+角度', () {
    final hit = hitTestRings([spec], .6, const Azimuth(100));
    expect(hit?.cell.name, 'B');
    expect(hitTestRings([spec], .9, const Azimuth(100)), isNull);
  });
}
