import 'dart:ui';

import 'package:fsc_domain/fsc_domain.dart';

/// 一圈的視覺規格:資料表 + 半徑帶 + 樣式(資料驅動渲染,02 §1)。
final class RingVisualSpec {
  /// 建立。半徑以盤半徑之比例表示(0–1),與螢幕尺寸無關。
  const RingVisualSpec({
    required this.table,
    required this.innerRadius,
    required this.outerRadius,
    required this.labelFontScale,
    this.minZoomForText = 0.0,
    this.colorByQuality = false,
  });

  /// 圈資料(格界+名稱+屬性)。
  final RingTable table;

  /// 內徑比例。
  final double innerRadius;

  /// 外徑比例。
  final double outerRadius;

  /// 字級比例(相對盤半徑)。
  final double labelFontScale;

  /// LOD:縮放低於此值時只畫格線不畫字(05 §2.2)。
  final double minZoomForText;

  /// 依分金品質著色(可用=竹青、空亡=朱砂、孤虛=淡)。
  final bool colorByQuality;

  /// 半徑帶中線比例。
  double get midRadius => (innerRadius + outerRadius) / 2;

  /// 命中測試:半徑比例是否落於本圈。
  bool containsRadius(double rRatio) =>
      rRatio >= innerRadius && rRatio < outerRadius;
}

/// 命中結果:哪一圈的哪一格。
typedef RingCellRef = ({String ringCode, RingCell cell});

/// 由極座標(半徑比例+方位角)找格(05 §2.3)。
RingCellRef? hitTestRings(
  List<RingVisualSpec> rings,
  double rRatio,
  Azimuth az,
) {
  for (final r in rings) {
    if (r.containsRadius(rRatio)) {
      return (ringCode: r.table.code, cell: r.table.cellAt(az));
    }
  }
  return null;
}
