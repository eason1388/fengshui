import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_ui/fsc_ui.dart';

import 'ring_visual_spec.dart';

/// 羅盤繪製器(05 §2.2 五層架構之 Layer 0–4 合成)。
///
/// 靜態圈層(盤底+格線+文字)繪製一次即快取為 [ui.Picture];
/// 之後每幀只做 canvas.rotate——這是 40+ 圈 60FPS 的關鍵。
class LuopanPainter extends CustomPainter {
  /// 建立。
  LuopanPainter({
    required this.rings,
    required this.rotationDeg,
    required this.zoom,
    required this.theme,
  });

  /// 圈層。
  final List<RingVisualSpec> rings;

  /// 盤面旋轉角(度,含手動偏移)。
  final double rotationDeg;

  /// 縮放(LOD 判斷用)。
  final double zoom;

  /// 深/淺色。
  final Brightness theme;

  static ui.Picture? _cache;
  static Object? _cacheKey;

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.shortestSide / 2;
    final center = size.center(Offset.zero);

    // Layer 0–1:靜態盤面(快取)
    final key = (rings.length, theme, zoom.toStringAsFixed(1), r.round());
    if (_cache == null || _cacheKey != key) {
      final rec = ui.PictureRecorder();
      _paintStatic(Canvas(rec), r);
      _cache = rec.endRecording();
      _cacheKey = key;
    }

    // Layer 3:旋轉容器
    canvas
      ..save()
      ..translate(center.dx, center.dy)
      ..rotate(rotationDeg * math.pi / 180)
      ..drawPicture(_cache!)
      ..restore();

    // Layer 4:天心十字線(固定不旋轉)
    final cross = Paint()
      ..color = FscColors.inauspicious.withOpacity(.85)
      ..strokeWidth = 1.2;
    canvas
      ..drawLine(Offset(center.dx, center.dy - r), Offset(center.dx, center.dy + r), cross)
      ..drawLine(Offset(center.dx - r, center.dy), Offset(center.dx + r, center.dy), cross);
  }

  void _paintStatic(Canvas canvas, double r) {
    final dark = theme == Brightness.dark;
    final bg = dark ? FscColors.surfaceDark : FscColors.surfaceLight;
    final ink = dark ? FscColors.onSurfaceDark : FscColors.onSurfaceLight;
    final gold = dark ? FscColors.primaryDark : FscColors.primaryLight;

    canvas.drawCircle(Offset.zero, r, Paint()..color = bg);
    canvas.drawCircle(
        Offset.zero, r, Paint()..color = gold..style = PaintingStyle.stroke..strokeWidth = 2);

    for (final ring in rings) {
      final rIn = ring.innerRadius * r;
      final rOut = ring.outerRadius * r;
      final line = Paint()
        ..color = gold.withOpacity(.55)
        ..style = PaintingStyle.stroke
        ..strokeWidth = .7;
      canvas.drawCircle(Offset.zero, rIn, line);
      canvas.drawCircle(Offset.zero, rOut, line);

      final showText = zoom >= ring.minZoomForText;
      for (final cell in ring.table.cells) {
        final startRad = (cell.startDeg - 90) * math.pi / 180;
        // 格線
        canvas.drawLine(
          Offset(math.cos(startRad) * rIn, math.sin(startRad) * rIn),
          Offset(math.cos(startRad) * rOut, math.sin(startRad) * rOut),
          line,
        );
        // 品質著色(分金)
        if (ring.colorByQuality && cell.quality != null) {
          final q = cell.quality!;
          final c = q.usable
              ? FscColors.auspicious
              : (q == FenJinQuality.kongWang ? FscColors.inauspicious : ink);
          _fillSector(canvas, rIn, rOut, cell.startDeg, cell.endDeg,
              c.withOpacity(q.usable ? .18 : .10));
        }
        // 徑向文字(下半盤自動翻轉,05 §9 已確認)
        if (showText && cell.name != null) {
          _radialText(canvas, cell.name!, ring, cell, r, ink);
        }
      }
    }
  }

  void _fillSector(Canvas canvas, double rIn, double rOut, double a0, double a1,
      Color color) {
    var sweep = (a1 - a0 + 360) % 360;
    final path = Path()
      ..addArc(Rect.fromCircle(center: Offset.zero, radius: rOut),
          (a0 - 90) * math.pi / 180, sweep * math.pi / 180)
      ..arcTo(Rect.fromCircle(center: Offset.zero, radius: rIn),
          (a0 + sweep - 90) * math.pi / 180, -sweep * math.pi / 180, false)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _radialText(Canvas canvas, String text, RingVisualSpec ring,
      RingCell cell, double r, Color ink) {
    var mid = (cell.startDeg + ((cell.endDeg - cell.startDeg + 360) % 360) / 2) % 360;
    final flip = mid > 90 && mid < 270; // 下半盤翻轉
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontFamily: FscTypography.serifFamily,
          fontSize: ring.labelFontScale * r,
          color: ink,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    canvas
      ..save()
      ..rotate((mid + (flip ? 180 : 0)) * math.pi / 180)
      ..translate(0, -(ring.midRadius * r) * (flip ? -1 : 1));
    tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
    canvas.restore();
  }

  @override
  bool shouldRepaint(LuopanPainter old) =>
      old.rotationDeg != rotationDeg || old.zoom != zoom || old.theme != theme;
}
