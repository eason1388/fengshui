import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:fsc_domain/fsc_domain.dart';

import 'luopan_painter.dart';
import 'ring_visual_spec.dart';

/// 羅盤顯示模式(05 §2.4 手勢狀態機)。
enum LuopanMode {
  /// 感測器即時驅動。
  live,

  /// 手動旋轉檢視(頂部顯示「回到實測」)。
  manual,

  /// 快照鎖定。
  locked,
}

/// 羅盤核心元件(05 §2)。
///
/// 渲染架構:靜態圈層繪入快取 Picture(Layer 0–1),
/// 每幀只旋轉畫布(Layer 3),天心線與高亮獨立小層(Layer 4)——
/// 穩態每幀成本≈一次矩陣旋轉,保障 60FPS(NFR)。
class LuopanView extends StatefulWidget {
  /// 建立羅盤。
  const LuopanView({
    required this.rings,
    required this.heading,
    this.mode = LuopanMode.live,
    this.onCellTap,
    this.onHeadingCommitted,
    super.key,
  });

  /// 圈層(由內而外)。
  final List<RingVisualSpec> rings;

  /// 方位流(真北;已由 fsc_sensors 融合)。
  final Stream<Azimuth> heading;

  /// 模式。
  final LuopanMode mode;

  /// 點格回呼(→ ExplainCard)。
  final ValueChanged<RingCellRef>? onCellTap;

  /// 讀數穩定後回報(→ ReadingBar)。
  final ValueChanged<Azimuth>? onHeadingCommitted;

  @override
  State<LuopanView> createState() => _LuopanViewState();
}

class _LuopanViewState extends State<LuopanView>
    with SingleTickerProviderStateMixin {
  double _rotationDeg = 0; // 盤面旋轉(=-heading,山向對準指北)
  double _manualOffset = 0; // 手動檢視偏移
  double _zoom = 1;
  late final AnimationController _springBack;

  @override
  void initState() {
    super.initState();
    _springBack = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 450),
    )..addListener(() {
        setState(() => _manualOffset *= 1 - _springBack.value);
      });
    widget.heading.listen((az) {
      if (!mounted || widget.mode == LuopanMode.locked) return;
      setState(() => _rotationDeg = -az.normalized().degrees);
      widget.onHeadingCommitted?.call(az);
    });
  }

  @override
  void dispose() {
    _springBack.dispose();
    super.dispose();
  }

  void _onPanUpdate(DragUpdateDetails d, Size size) {
    // 以盤心為軸,將拖曳位移換算為角位移。
    final c = size.center(Offset.zero);
    final p = d.localPosition - c;
    final before = math.atan2(p.dy - d.delta.dy, p.dx - d.delta.dx);
    final after = math.atan2(p.dy, p.dx);
    setState(() => _manualOffset += (after - before) * 180 / math.pi);
  }

  void _onTapUp(TapUpDetails d, Size size) {
    final c = size.center(Offset.zero);
    final p = d.localPosition - c;
    final rPx = p.distance;
    final rRatio = rPx / (size.shortestSide / 2 * _zoom);
    // 螢幕角(0=北、順時針)扣除盤面旋轉=盤上方位角。
    final screenDeg = (math.atan2(p.dx, -p.dy) * 180 / math.pi + 360) % 360;
    final az = Azimuth(screenDeg - _rotationDeg - _manualOffset).normalized();
    final hit = hitTestRings(widget.rings, rRatio, az);
    if (hit != null) widget.onCellTap?.call(hit);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final size = Size.square(constraints.biggest.shortestSide);
      return GestureDetector(
        onPanUpdate: (d) => _onPanUpdate(d, size),
        onPanEnd: (_) => _springBack.forward(from: 0), // 鬆手回彈 live
        onTapUp: (d) => _onTapUp(d, size),
        child: Transform.scale(
          scale: _zoom,
          child: CustomPaint(
            size: size,
            isComplex: true,
            willChange: true,
            painter: LuopanPainter(
              rings: widget.rings,
              rotationDeg: _rotationDeg + _manualOffset,
              zoom: _zoom,
              theme: Theme.of(context).brightness,
            ),
          ),
        ),
      );
    });
  }
}
