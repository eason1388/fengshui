import 'package:flutter/material.dart';
import 'package:fsc_ui/fsc_ui.dart';

/// 五段式解說內容(FR-G3;正式文案來自 explain_cards 資料表)。
final class Explain5 {
  /// 建立。
  const Explain5({
    required this.what,
    required this.current,
    required this.meaning,
    required this.fortune,
    required this.next,
  });

  /// ① 這是什麼。
  final String what;

  /// ② 現在指到什麼(即時代入讀數)。
  final String current;

  /// ③ 代表什麼意思。
  final String meaning;

  /// ④ 吉凶如何(含理由)。
  final String fortune;

  /// ⑤ 下一步怎麼判斷。
  final String next;
}

/// 五段式詳解卡(05 §3.2)。半屏 BottomSheet,可上滑全屏。
class ExplainCard extends StatelessWidget {
  /// 建立。
  const ExplainCard({
    required this.title,
    required this.explain,
    this.onAskAi,
    super.key,
  });

  /// 標題(如「丙(二十四山)」)。
  final String title;

  /// 五段內容。
  final Explain5 explain;

  /// 問 AI。
  final VoidCallback? onAskAi;

  /// 以 BottomSheet 顯示。
  static Future<void> show(
    BuildContext context, {
    required String title,
    required Explain5 explain,
    VoidCallback? onAskAi,
  }) =>
      showModalBottomSheet<void>(
        context: context,
        showDragHandle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
              top: Radius.circular(FscSpacing.radiusSheet)),
        ),
        builder: (_) =>
            ExplainCard(title: title, explain: explain, onAskAi: onAskAi),
      );

  @override
  Widget build(BuildContext context) {
    final rows = [
      ('① 這是什麼', explain.what),
      ('② 現在指到', explain.current),
      ('③ 代表什麼', explain.meaning),
      ('④ 吉凶如何', explain.fortune),
      ('⑤ 下一步', explain.next),
    ];
    return Padding(
      padding: const EdgeInsets.all(FscSpacing.xl),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: FscTypography.title),
          const SizedBox(height: FscSpacing.md),
          for (final (label, text) in rows)
            Padding(
              padding: const EdgeInsets.only(bottom: FscSpacing.sm),
              child: Text('$label:$text', style: FscTypography.body),
            ),
          const SizedBox(height: FscSpacing.md),
          FilledButton.icon(
            onPressed: onAskAi,
            icon: const Icon(Icons.chat_bubble_outline),
            label: const Text('問 AI'),
          ),
        ],
      ),
    );
  }
}
