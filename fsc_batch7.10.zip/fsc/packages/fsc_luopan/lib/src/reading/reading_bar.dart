import 'package:flutter/material.dart';
import 'package:fsc_domain/fsc_domain.dart';
import 'package:fsc_ui/fsc_ui.dart';

/// 判讀列(05 §3.1):度數+山向大字、兼向/分金/警告 chips。
/// 全部內容源自 [BearingReading],UI 不自行換算(03 §3)。
class ReadingBar extends StatelessWidget {
  /// 建立。
  const ReadingBar({required this.reading, this.onExpand, super.key});

  /// 判讀結果。
  final BearingReading reading;

  /// 展開全欄位。
  final VoidCallback? onExpand;

  @override
  Widget build(BuildContext context) {
    final r = reading;
    final warnings = r.warnings.map((w) => switch (w) {
          QiFengLine() => '⚠ 騎縫線',
          KongWangLine() => '⚠ 空亡',
          ChaCuoLine() => '⚠ 差錯',
        });
    return Material(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(FscSpacing.radiusCard),
      child: InkWell(
        onTap: onExpand,
        borderRadius: BorderRadius.circular(FscSpacing.radiusCard),
        child: Padding(
          padding: const EdgeInsets.all(FscSpacing.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '${r.azimuth.degrees.toStringAsFixed(1)}°  ${r.title}',
                style: FscTypography.reading,
              ),
              const SizedBox(height: FscSpacing.xs),
              Wrap(
                spacing: FscSpacing.sm,
                children: [
                  Chip(
                    label: Text(r.jian.isPure
                        ? '正向'
                        : '兼${r.jian.leanTo?.zh}${r.jian.leanDeg.abs()}°'
                          '${r.jian.requiresTiGua ? '(須替卦)' : ''}'),
                  ),
                  Chip(
                    label: Text(
                        '分金:${r.fenJin.name}(${r.fenJin.quality?.zh})'),
                  ),
                  for (final w in warnings)
                    Chip(
                      label: Text(w),
                      backgroundColor: FscColors.inauspicious.withOpacity(.15),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
