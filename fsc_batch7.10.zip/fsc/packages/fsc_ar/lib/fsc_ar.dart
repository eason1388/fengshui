/// fsc_ar:AR 模式抽象層。
/// 原則:所有玄學計算(山向/飛星/吉凶)由既有引擎完成,
/// AR 層只負責「把結果錨定到實景」;無 AR 能力之裝置自動降級地圖模式。
library fsc_ar;

export 'src/ar_session.dart';
