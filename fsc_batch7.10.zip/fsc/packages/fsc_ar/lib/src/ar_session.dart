import 'package:fsc_domain/fsc_domain.dart';

/// AR 疊加元素。
sealed class ArOverlay {
  const ArOverlay();
}

/// 方位扇形牆(如吉位綠/凶位紅,自使用者向外 [radiusM] 公尺)。
final class ArSectorWall extends ArOverlay {
  /// 建立。
  const ArSectorWall({
    required this.startDeg,
    required this.endDeg,
    required this.colorHint, // 'auspicious' / 'inauspicious' / 'neutral'
    this.radiusM = 5,
    this.label,
  });

  /// 扇形起訖(真北)。
  final double startDeg;

  /// 訖角。
  final double endDeg;

  /// 顏色語意。
  final String colorHint;

  /// 半徑。
  final double radiusM;

  /// 標籤(如「生氣」「五黃」)。
  final String? label;
}

/// 水平羅盤盤面投影(錨定於地面)。
final class ArCompassDisc extends ArOverlay {
  /// 建立。
  const ArCompassDisc({required this.rings, this.radiusM = 1.5});

  /// 要顯示之圈層代碼(沿用 ring_definitions)。
  final List<String> rings;

  /// 半徑。
  final double radiusM;
}

/// AR 會話能力與生命週期(ARKit/ARCore 實作注入)。
abstract interface class ArSession {
  /// 裝置是否支援(不支援→UI 導向地圖模式,01 §6 平台矩陣)。
  Future<bool> get isSupported;

  /// 啟動(相機權限由呼叫方先取得)。
  Future<void> start();

  /// 更新疊加(每次判讀/吉位變更時呼叫;實作負責姿態追蹤)。
  Future<void> setOverlays(List<ArOverlay> overlays, {required Azimuth trueNorthRef});

  /// 停止。
  Future<void> stop();
}

/// 由八宅盤生成 AR 吉凶扇形(每宮 45°,依後天卦方位)。
List<ArSectorWall> sectorsFromBaZhai(BaZhaiChart chart) {
  const gongCenter = {
    Trigram.kan: 0.0, Trigram.gen: 45.0, Trigram.zhen: 90.0, Trigram.xun: 135.0,
    Trigram.li: 180.0, Trigram.kun: 225.0, Trigram.dui: 270.0, Trigram.qian: 315.0,
  };
  return chart.byGong.entries.map((e) {
    final c = gongCenter[e.key]!;
    return ArSectorWall(
      startDeg: (c - 22.5 + 360) % 360,
      endDeg: (c + 22.5) % 360,
      colorHint: e.value.auspicious ? 'auspicious' : 'inauspicious',
      label: e.value.zh,
    );
  }).toList();
}
