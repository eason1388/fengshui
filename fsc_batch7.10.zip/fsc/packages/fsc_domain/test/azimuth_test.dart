import 'package:fsc_domain/fsc_domain.dart';
import 'package:test/test.dart';

void main() {
  group('Azimuth', () {
    test('normalized 邊界', () {
      expect(const Azimuth(360).normalized().degrees, 0);
      expect(const Azimuth(-1).normalized().degrees, 359);
      expect(const Azimuth(725.5).normalized().degrees, closeTo(5.5, 1e-9));
    });
    test('isWithin 跨 0°(子山 352.5–7.5)', () {
      expect(const Azimuth(355).isWithin(352.5, 7.5), isTrue);
      expect(const Azimuth(3).isWithin(352.5, 7.5), isTrue);
      expect(const Azimuth(8).isWithin(352.5, 7.5), isFalse);
    });
    test('distanceTo 最短夾角', () {
      expect(const Azimuth(350).distanceTo(const Azimuth(10)), 20);
    });
    test('opposite', () {
      expect(const Azimuth(278).opposite.degrees, 98);
    });
  });

  group('Mountain24', () {
    test('278° → 辛山、對宮乙(需求 FR-E「AI 判斷」範例)', () {
      final m = Mountain24.fromAzimuth(const Azimuth(278));
      expect(m, Mountain24.xin);
      expect(m.opposite, Mountain24.yi); // 辛山乙向
    });
    test('每山邊界 ±0.01°', () {
      for (final m in Mountain24.values) {
        expect(Mountain24.fromAzimuth(Azimuth(m.startDeg + 0.01)), m);
        expect(Mountain24.fromAzimuth(Azimuth(m.centerDeg)), m);
        expect(Mountain24.fromAzimuth(Azimuth(m.endDeg - 0.01)), m);
      }
    });
    test('24 山合計無縫覆蓋 360°', () {
      final total = Mountain24.values.length * Mountain24.span;
      expect(total, 360);
    });
    test('騎縫距離:337.5° 在壬子界上', () {
      expect(Mountain24.distanceToBoundary(const Azimuth(337.5)), 0);
      expect(Mountain24.distanceToBoundary(const Azimuth(345)), 7.5);
    });
  });

  group('GanZhi', () {
    test('六十甲子干支互算', () {
      expect(const GanZhi(0).zh, '甲子');
      expect(const GanZhi(54).zh, '戊午');
      expect(const GanZhi(59).zh, '癸亥');
      expect(GanZhi.of(Stem.wu, Branch.wuma).index, 54);
    });
    test('陰陽不配即拒絕', () {
      expect(() => GanZhi.of(Stem.jia, Branch.chou), throwsArgumentError);
    });
    test('納音:甲子乙丑海中金、戊午己未天上火', () {
      expect(const GanZhi(0).naYin, '海中金');
      expect(const GanZhi(54).naYin, '天上火');
    });
  });

  group('Period', () {
    test('2024–2043 為九運、2004–2023 八運', () {
      expect(Period.fromYear(2026), Period.p9);
      expect(Period.fromYear(2023), Period.p8);
      expect(Period.fromYear(1996), Period.p7);
    });
  });
}
