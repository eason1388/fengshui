/// fsc_domain:全 App 的核心語彙。零 Flutter、零外部依賴(03 §1)。
library fsc_domain;

export 'src/core/azimuth.dart';
export 'src/core/cosmology.dart';
export 'src/core/ganzhi.dart';
export 'src/core/mountain24.dart';
export 'src/engines/bearing_interpreter.dart';
export 'src/engines/calendar_engine.dart';
export 'src/models/bearing_reading.dart';
export 'src/models/ganzhi_date.dart';
export 'src/models/ring_tables.dart';
export 'src/core/sanyuan.dart';
export 'src/models/bazhai.dart';
export 'src/models/flying_star.dart';
export 'src/models/shensha.dart';
export 'src/models/bazi.dart';
export 'src/models/theory.dart';
