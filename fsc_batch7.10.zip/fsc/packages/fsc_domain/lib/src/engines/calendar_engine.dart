import '../models/ganzhi_date.dart';

/// 二十四節氣(依黃經序,立春 315° 起為歲首慣例)。
enum SolarTermType {
  /// 立春(315°)。
  liChun(315, '立春'),
  /// 雨水(330°)。
  yuShui(330, '雨水'),
  /// 驚蟄(345°)。
  jingZhe(345, '驚蟄'),
  /// 春分(0°)。
  chunFen(0, '春分'),
  /// 清明(15°)。
  qingMing(15, '清明'),
  /// 穀雨(30°)。
  guYu(30, '穀雨'),
  /// 立夏(45°)。
  liXia(45, '立夏'),
  /// 小滿(60°)。
  xiaoMan(60, '小滿'),
  /// 芒種(75°)。
  mangZhong(75, '芒種'),
  /// 夏至(90°)。
  xiaZhi(90, '夏至'),
  /// 小暑(105°)。
  xiaoShu(105, '小暑'),
  /// 大暑(120°)。
  daShu(120, '大暑'),
  /// 立秋(135°)。
  liQiu(135, '立秋'),
  /// 處暑(150°)。
  chuShu(150, '處暑'),
  /// 白露(165°)。
  baiLu(165, '白露'),
  /// 秋分(180°)。
  qiuFen(180, '秋分'),
  /// 寒露(195°)。
  hanLu(195, '寒露'),
  /// 霜降(210°)。
  shuangJiang(210, '霜降'),
  /// 立冬(225°)。
  liDong(225, '立冬'),
  /// 小雪(240°)。
  xiaoXue(240, '小雪'),
  /// 大雪(255°)。
  daXue(255, '大雪'),
  /// 冬至(270°)。
  dongZhi(270, '冬至'),
  /// 小寒(285°)。
  xiaoHan(285, '小寒'),
  /// 大寒(300°)。
  daHan(300, '大寒');

  const SolarTermType(this.longitude, this.zh);

  /// 太陽視黃經(度)。
  final int longitude;

  /// 中文名。
  final String zh;

  /// 是否為「節」(月界;立春/驚蟄/清明…,黃經為 15° 奇數倍)。
  bool get isJie => longitude % 30 == 15 || longitude % 30 == 15 - 30;
}

/// 歲界規則(03 §4;預設立春,設定可換)。
enum YearBoundary {
  /// 立春換年柱(子平通例,01 §12 已確認為預設)。
  liChun,
  /// 冬至換年柱(部分門派)。
  dongZhi,
}

/// 晚子時規則:23:00–24:00 出生,日柱是否用翌日。
enum LateZiRule {
  /// 23:00 起即算翌日(傳統通行)。
  nextDay,
  /// 24:00 才換日(晚子時派)。
  midnight,
}

/// 曆法引擎介面——所有動態盤(飛星、神煞、八字)的地基(03 §4)。
abstract interface class CalendarEngine {
  /// 引擎版本(結果快取綁定,03 §1)。
  String get version;

  /// 求某年某節氣的精確時刻(UTC)。
  DateTime termInstant(int year, SolarTermType term);

  /// 給定 UTC 時刻的「當前節氣」(最近一個已過之節氣)。
  SolarTermType currentTerm(DateTime utc);

  /// 排四柱。[local] 為出生地當地時刻(真太陽時修正由上游完成)。
  /// [utcOffsetMinutes] 當地時區偏移(分)。
  GanZhiDate fourPillars(
    DateTime local, {
    required int utcOffsetMinutes,
    YearBoundary yearBoundary = YearBoundary.liChun,
    LateZiRule lateZi = LateZiRule.nextDay,
    bool hourUncertain = false,
  });
}
