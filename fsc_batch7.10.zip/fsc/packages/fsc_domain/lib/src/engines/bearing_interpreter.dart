import '../core/azimuth.dart';
import '../models/bearing_reading.dart';

/// 判讀門檻設定(門派包可覆寫,03 §15 已確認之預設)。
final class TheoryConfig {
  /// 建立設定。
  const TheoryConfig({
    this.jianThresholdDeg = 3,
    this.tiGuaThresholdDeg = 4.5,
    this.qiFengThresholdDeg = 1.0,
  });

  /// 偏離山中線超過此值起算「兼」。
  final double jianThresholdDeg;

  /// 偏離超過此值須起替卦。
  final double tiGuaThresholdDeg;

  /// 距山界小於此值判「騎縫」。
  final double qiFengThresholdDeg;
}

/// 判讀引擎介面:度數 → 完整判讀(FR-A2「AI 判斷」)。純函數。
abstract interface class BearingInterpreter {
  /// 引擎版本。
  String get version;

  /// 判讀。[az] 為量測方位(真北);[isSitting] 指明量的是坐或向。
  BearingReading interpret(
    Azimuth az, {
    required bool isSitting,
    TheoryConfig config = const TheoryConfig(),
  });
}
