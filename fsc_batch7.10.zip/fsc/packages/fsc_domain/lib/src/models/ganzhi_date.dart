import '../core/ganzhi.dart';

/// 四柱(年/月/日/時干支)——八字排盤的原料(03 §4)。不可變。
final class GanZhiDate {
  /// 建立四柱。
  const GanZhiDate({
    required this.year,
    required this.month,
    required this.day,
    required this.hour,
    this.hourUncertain = false,
  });

  /// 年柱(以立春為歲界,除非設定改為冬至/正月)。
  final GanZhi year;

  /// 月柱(以節氣「節」為月界)。
  final GanZhi month;

  /// 日柱。
  final GanZhi day;

  /// 時柱。
  final GanZhi hour;

  /// 出生時辰不確定(01 §FR-E1):下游分析須降級並標註。
  final bool hourUncertain;

  @override
  String toString() =>
      '${year.zh}年 ${month.zh}月 ${day.zh}日 ${hour.zh}時${hourUncertain ? '(時辰存疑)' : ''}';
}
