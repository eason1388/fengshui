import '../core/azimuth.dart';

/// 分金品質(口訣:丙丁旺、庚辛相=可用;甲乙孤、壬癸虛=不用;戊己=龜甲空亡)。
enum FenJinQuality {
  /// 旺(丙丁)。
  wang('旺', true),
  /// 相(庚辛)。
  xiang('相', true),
  /// 孤(甲乙)。
  gu('孤', false),
  /// 虛(壬癸)。
  xu('虛', false),
  /// 龜甲空亡(戊己)。
  kongWang('龜甲空亡', false);

  const FenJinQuality(this.zh, this.usable);

  /// 中文。
  final String zh;

  /// 是否可用(FR-A 需求 12:自動提示可用/差錯/空亡)。
  final bool usable;
}

/// 環形查找表的一格(半開區間 [startDeg, endDeg),可跨 0°)。
final class RingCell {
  /// 建立格子。
  const RingCell({
    required this.index,
    required this.startDeg,
    required this.endDeg,
    this.name,
    this.ganZhiIndex,
    this.naYin,
    this.quality,
  });

  /// 圈內序(0 起,順時針)。
  final int index;

  /// 起始角(含)。
  final double startDeg;

  /// 結束角(不含)。
  final double endDeg;

  /// 名稱(如「丙子」);穿山七十二龍之空亡格為 null。
  final String? name;

  /// 六十甲子序(0=甲子);空亡格為 null。
  final int? ganZhiIndex;

  /// 納音。
  final String? naYin;

  /// 分金品質(僅分金圈使用)。
  final FenJinQuality? quality;

  /// 是否空亡格(七十二龍)。
  bool get isBlank => name == null;

  /// 方位角是否落在本格。
  bool contains(Azimuth az) => az.isWithin(startDeg, endDeg);
}

/// 一整圈(等分格,O(1) 定位)。
final class RingTable {
  /// 建立圈。[anchorDeg] 首格起始角,[span] 每格度數。
  const RingTable({
    required this.code,
    required this.anchorDeg,
    required this.span,
    required this.cells,
  });

  /// 圈代碼(fenjin_120 / dragons_72 / dragons_60)。
  final String code;

  /// 首格起始角。
  final double anchorDeg;

  /// 每格跨度。
  final double span;

  /// 全部格子(依 index 排序)。
  final List<RingCell> cells;

  /// 由方位角取格(等分圈 O(1))。
  RingCell cellAt(Azimuth az) {
    final d = az.normalized().degrees;
    final i = ((((d - anchorDeg) % 360) + 360) % 360) ~/ span;
    return cells[i.toInt()];
  }
}
