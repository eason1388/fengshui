import '../core/cosmology.dart';
import '../core/mountain24.dart';

/// 一宮之三星。
final class PalaceStars {
  /// 建立。
  const PalaceStars({
    required this.palace,
    required this.mountain,
    required this.facing,
    required this.base,
  });

  /// 宮位。
  final Palace palace;

  /// 山星。
  final int mountain;

  /// 向星。
  final int facing;

  /// 運星。
  final int base;
}

/// 四大格局。
enum ChartPattern {
  /// 旺山旺向(到山到向)。
  wangShanWangXiang('旺山旺向'),
  /// 上山下水。
  shangShanXiaShui('上山下水'),
  /// 雙星會向。
  doubleAtFacing('雙星會向'),
  /// 雙星會坐。
  doubleAtSitting('雙星會坐'),
  /// 其他。
  other('其他');

  const ChartPattern(this.zh);

  /// 中文。
  final String zh;
}

/// 三般卦。
enum SanBanGua {
  /// 父母三般卦(147/258/369)。
  parent('父母三般卦'),
  /// 連珠三般卦(連續三數)。
  lianZhu('連珠三般卦');

  const SanBanGua(this.zh);

  /// 中文。
  final String zh;
}

/// 城門。
final class ChengMen {
  /// 建立。
  const ChengMen({required this.palace, required this.isPrimary, required this.usable});

  /// 所在宮。
  final Palace palace;

  /// 正城門(與向宮洛書數合生成)?否則副城門。
  final bool isPrimary;

  /// 可用(該宮同元龍屬陰,逆飛令旺星到宮)。
  final bool usable;
}

/// 玄空飛星宅盤(03 §5)。
final class FlyingStarChart {
  /// 建立。
  const FlyingStarChart({
    required this.period,
    required this.sitting,
    required this.facing,
    required this.isTiGua,
    required this.palaces,
    required this.pattern,
    required this.sanBan,
    required this.gates,
    required this.warnings,
  });

  /// 元運。
  final Period period;

  /// 坐山。
  final Mountain24 sitting;

  /// 向山。
  final Mountain24 facing;

  /// 是否替卦盤。
  final bool isTiGua;

  /// 九宮三星。
  final Map<Palace, PalaceStars> palaces;

  /// 格局。
  final ChartPattern pattern;

  /// 三般卦(無則 null)。
  final SanBanGua? sanBan;

  /// 城門(正/副)。
  final List<ChengMen> gates;

  /// 伏吟/反吟等警示(i18n key)。
  final List<String> warnings;
}
