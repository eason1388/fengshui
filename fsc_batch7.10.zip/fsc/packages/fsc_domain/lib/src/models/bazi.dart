import '../core/cosmology.dart';
import '../core/ganzhi.dart';
import 'ganzhi_date.dart';

/// 十神。
enum TenGod {
  /// 比肩。
  biJian('比肩'),
  /// 劫財。
  jieCai('劫財'),
  /// 食神。
  shiShen('食神'),
  /// 傷官。
  shangGuan('傷官'),
  /// 偏財。
  pianCai('偏財'),
  /// 正財。
  zhengCai('正財'),
  /// 七殺。
  qiSha('七殺'),
  /// 正官。
  zhengGuan('正官'),
  /// 偏印。
  pianYin('偏印'),
  /// 正印。
  zhengYin('正印');

  const TenGod(this.zh);

  /// 中文。
  final String zh;
}

/// 五行強弱結果(v1 透明計分模型;權重存 bazi_rules 可調)。
final class WuXingStrength {
  /// 建立。
  const WuXingStrength({
    required this.points,
    required this.sameFactionRatio,
    required this.verdict,
  });

  /// 各五行得分。
  final Map<WuXing, double> points;

  /// 同黨(同我+生我)佔比。
  final double sameFactionRatio;

  /// 身強/身弱/中和。
  final String verdict; // i18n key:strength.strong/weak/balanced

  /// 是否身弱。
  bool get isWeak => sameFactionRatio < 0.45;

  /// 是否身強。
  bool get isStrong => sameFactionRatio > 0.55;
}

/// 一步大運。
final class DaYun {
  /// 建立。
  const DaYun({required this.pillar, required this.startAge});

  /// 干支柱。
  final GanZhi pillar;

  /// 起始虛歲(近似,精確排法 v2)。
  final double startAge;
}

/// 八字命盤(03 §7)。
final class BaziChart {
  /// 建立。
  const BaziChart({
    required this.pillars,
    required this.dayMaster,
    required this.tenGods,
    required this.strength,
    required this.favorable,
    required this.daYun,
    required this.forward,
  });

  /// 四柱。
  final GanZhiDate pillars;

  /// 日主。
  final Stem dayMaster;

  /// 各柱天干十神(日柱=日主本身,標比肩)。
  final Map<String, TenGod> tenGods; // key: year/month/hour

  /// 五行強弱。
  final WuXingStrength strength;

  /// 喜用五行(依強弱推;中和為空,由調候補充)。
  final List<WuXing> favorable;

  /// 大運(8 步)。
  final List<DaYun> daYun;

  /// 大運順排?
  final bool forward;
}
