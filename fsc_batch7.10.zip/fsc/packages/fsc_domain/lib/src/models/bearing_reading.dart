import '../core/azimuth.dart';
import '../core/mountain24.dart';
import 'ring_tables.dart';

/// 兼向資訊(03 §3;門檻依 01/03 已確認:±3° 起算兼、>4.5° 用替)。
final class JianXiang {
  /// 建立。
  const JianXiang({
    required this.isPure,
    required this.leanTo,
    required this.leanDeg,
    required this.requiresTiGua,
  });

  /// 正向(未兼)。
  final bool isPure;

  /// 兼向之山(未兼為 null)。
  final Mountain24? leanTo;

  /// 兼幾度(正=順時針偏)。
  final double leanDeg;

  /// 是否須起替卦(玄空)。
  final bool requiresTiGua;
}

/// 凶線警告(sealed:窮舉處理,UI 不可能漏接)。
sealed class LineWarning {
  const LineWarning();
}

/// 騎縫線(壓兩山交界)。
final class QiFengLine extends LineWarning {
  /// 建立;[boundaryDeg] 所壓山界。
  const QiFengLine(this.boundaryDeg);

  /// 所壓山界角度。
  final double boundaryDeg;
}

/// 空亡線(落戊己龜甲空亡分金)。
final class KongWangLine extends LineWarning {
  /// 建立。
  const KongWangLine();
}

/// 差錯線(落孤虛分金)。
final class ChaCuoLine extends LineWarning {
  /// 建立。
  const ChaCuoLine();
}

/// 一次量測的完整判讀(03 §3)。「278° → 辛山乙向」之載體;
/// 全部 UI 顯示皆源於本物件,不允許 UI 自行換算。
final class BearingReading {
  /// 建立。
  const BearingReading({
    required this.azimuth,
    required this.isSitting,
    required this.sitting,
    required this.facing,
    required this.jian,
    required this.warnings,
    required this.fenJin,
    required this.dragon72,
    required this.dragon60,
  });

  /// 原始讀數(真北)。
  final Azimuth azimuth;

  /// 使用者宣告讀的是「坐」。
  final bool isSitting;

  /// 坐山。
  final Mountain24 sitting;

  /// 向山。
  final Mountain24 facing;

  /// 兼向。
  final JianXiang jian;

  /// 凶線警告(可複數)。
  final List<LineWarning> warnings;

  /// 所落分金格。
  final RingCell fenJin;

  /// 所落穿山七十二龍格(可能為空亡格)。
  final RingCell dragon72;

  /// 所落透地六十龍格。
  final RingCell dragon60;

  /// 山向文字(如「辛山乙向」)。
  String get title => '${sitting.zh}山${facing.zh}向';
}
