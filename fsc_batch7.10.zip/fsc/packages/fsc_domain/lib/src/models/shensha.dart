import '../core/cosmology.dart';
import '../core/ganzhi.dart';

/// 年神煞方位(FR-C4)。
final class AnnualShenSha {
  /// 建立。
  const AnnualShenSha({
    required this.suiYear,
    required this.taiSui,
    required this.suiPo,
    required this.sanSha,
    required this.wuHuang,
  });

  /// 歲年(立春界)。
  final int suiYear;

  /// 太歲所在支。
  final Branch taiSui;

  /// 歲破所在支。
  final Branch suiPo;

  /// 三煞所占三支(如午年煞北:亥子丑)。
  final List<Branch> sanSha;

  /// 五黃所到宮。
  final Palace wuHuang;
}

/// 個人吉位(FR-C5;依命)。
final class PersonalPositions {
  /// 建立。
  const PersonalPositions({
    required this.wenChang,
    required this.taoHua,
    required this.yiMa,
    required this.guiRen,
  });

  /// 本命文昌(依年干)。
  final Branch wenChang;

  /// 桃花(依年支三合)。
  final Branch taoHua;

  /// 驛馬(依年支三合)。
  final Branch yiMa;

  /// 天乙貴人(依年干,恆為兩支)。
  final List<Branch> guiRen;
}
