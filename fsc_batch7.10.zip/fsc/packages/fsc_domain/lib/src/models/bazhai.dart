import '../core/cosmology.dart';

/// 八宅遊星。
enum WanderingStar {
  /// 伏位。
  fuWei('伏位', true),
  /// 生氣(貪狼)。
  shengQi('生氣', true),
  /// 絕命(破軍)。
  jueMing('絕命', false),
  /// 五鬼(廉貞)。
  wuGui('五鬼', false),
  /// 禍害(祿存)。
  huoHai('禍害', false),
  /// 六煞(文曲)。
  liuSha('六煞', false),
  /// 天醫(巨門)。
  tianYi('天醫', true),
  /// 延年(武曲)。
  yanNian('延年', true);

  const WanderingStar(this.zh, this.auspicious);

  /// 中文。
  final String zh;

  /// 吉星?
  final bool auspicious;
}

/// 東西四命/宅。
enum EastWest {
  /// 東四(坎離震巽)。
  east('東四'),
  /// 西四(乾坤艮兌)。
  west('西四');

  const EastWest(this.zh);

  /// 中文。
  final String zh;
}

/// 八宅盤。
final class BaZhaiChart {
  /// 建立。
  const BaZhaiChart({required this.gua, required this.byGong});

  /// 宅卦(或命卦)。
  final Trigram gua;

  /// 各宮遊星。
  final Map<Trigram, WanderingStar> byGong;

  /// 東四/西四。
  EastWest get group => const {
        Trigram.kan, Trigram.li, Trigram.zhen, Trigram.xun,
      }.contains(gua)
      ? EastWest.east
      : EastWest.west;
}
