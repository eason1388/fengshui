/// 門派規則包(02 §2.5 theory_packs;03 §10 DSL)。
final class TheoryPack {
  /// 建立。
  const TheoryPack({
    required this.code,
    required this.name,
    required this.version,
    required this.rules,
    this.builtin = true,
  });

  /// 代碼(xuankong_shen / sanhe / bazhai …)。
  final String code;

  /// 名稱。
  final String name;

  /// semver。
  final String version;

  /// 規則。
  final List<TheoryRule> rules;

  /// 內建?(false=使用者自訂)
  final bool builtin;
}

/// 規則種類。
enum RuleKind {
  /// 計分。
  scoring,

  /// 論斷解說。
  interpretation,

  /// 警告。
  warning,

  /// 吉位標示。
  position,
}

/// 單條規則。condition/conclusion 為 JSON(DSL 非圖靈完備:
/// 無迴圈、無自訂函數、fact 路徑白名單——使用者包無法執行任意程式)。
final class TheoryRule {
  /// 建立。
  const TheoryRule({
    required this.id,
    required this.kind,
    required this.condition,
    required this.conclusion,
    required this.sourceRef,
    this.weight = 1.0,
    this.scope = const ['yangzhai'],
  });

  /// 規則 id。
  final String id;

  /// 種類。
  final RuleKind kind;

  /// 條件 JSON(見 evaluator)。
  final Map<String, dynamic> condition;

  /// 結論 JSON:{textKey, score, verdict, remedyKeys}。
  final Map<String, dynamic> conclusion;

  /// 出處(必填,審校依據)。
  final String sourceRef;

  /// 綜合模式權重。
  final double weight;

  /// 適用場景。
  final List<String> scope;
}

/// 規則命中結果。
final class RuleHit {
  /// 建立。
  const RuleHit({
    required this.rule,
    required this.bindings,
    required this.weightedScore,
  });

  /// 命中之規則。
  final TheoryRule rule;

  /// 萬用字元綁定(如 P→li9)。
  final Map<String, String> bindings;

  /// score×weight。
  final double weightedScore;
}
