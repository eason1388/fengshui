import 'azimuth.dart';

/// 二十四山(每山 15°,壬起 337.5°,順時針)。
///
/// 僅承載「識別+幾何+基本結構」;五行、納甲、旺衰等完整屬性
/// 由玄學資料包提供(02 §2.3 mountains_24),避免硬編碼難以審校。
enum Mountain24 {
  /// 壬。
  ren('壬'),
  /// 子。
  zi('子'),
  /// 癸。
  gui('癸'),
  /// 丑。
  chou('丑'),
  /// 艮。
  gen('艮'),
  /// 寅。
  yin('寅'),
  /// 甲。
  jia('甲'),
  /// 卯。
  mao('卯'),
  /// 乙。
  yi('乙'),
  /// 辰。
  chen('辰'),
  /// 巽。
  xun('巽'),
  /// 巳。
  si('巳'),
  /// 丙。
  bing('丙'),
  /// 午。
  wu('午'),
  /// 丁。
  ding('丁'),
  /// 未。
  wei('未'),
  /// 坤。
  kun('坤'),
  /// 申。
  shen('申'),
  /// 庚。
  geng('庚'),
  /// 酉。
  you('酉'),
  /// 辛。
  xin('辛'),
  /// 戌。
  xu('戌'),
  /// 乾。
  qian('乾'),
  /// 亥。
  hai('亥');

  const Mountain24(this.zh);

  /// 中文名。
  final String zh;

  /// 首山(壬)起始角。
  static const double firstStartDeg = 337.5;

  /// 每山跨度。
  static const double span = 15;

  /// 本山起始角(含)。
  double get startDeg => (firstStartDeg + index * span) % 360;

  /// 本山結束角(不含)。
  double get endDeg => (startDeg + span) % 360;

  /// 本山中心角(正針)。
  double get centerDeg => (startDeg + span / 2) % 360;

  /// 對宮之山(坐↔向)。
  Mountain24 get opposite => Mountain24.values[(index + 12) % 24];

  /// 由方位角判山。278° → 辛。
  static Mountain24 fromAzimuth(Azimuth az) {
    final d = az.normalized().degrees;
    final i = (((d - firstStartDeg) % 360 + 360) % 360) ~/ span;
    return Mountain24.values[i];
  }

  /// 距最近山界(騎縫線)的角距;判讀層據此發出 [騎縫] 警告(03 §3)。
  static double distanceToBoundary(Azimuth az) {
    final d = az.normalized().degrees;
    final offset = ((d - firstStartDeg) % span + span) % span;
    return offset < span / 2 ? offset : span - offset;
  }
}
