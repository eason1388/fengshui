/// 基礎玄學枚舉:五行、八卦、九宮、九星、三元九運。
library;

/// 五行。
enum WuXing {
  /// 木。
  wood('木'),
  /// 火。
  fire('火'),
  /// 土。
  earth('土'),
  /// 金。
  metal('金'),
  /// 水。
  water('水');

  const WuXing(this.zh);

  /// 中文名。
  final String zh;

  /// 我生者(木生火…)。
  WuXing get sheng => WuXing.values[(index + 1) % 5];

  /// 我剋者(木剋土…)。
  WuXing get ke => WuXing.values[(index + 2) % 5];
}

/// 八卦(含先/後天方位與五行;完整屬性由資料包補充,見 02 §2.3)。
enum Trigram {
  /// 乾 ☰。
  qian('乾', WuXing.metal),
  /// 兌 ☱。
  dui('兌', WuXing.metal),
  /// 離 ☲。
  li('離', WuXing.fire),
  /// 震 ☳。
  zhen('震', WuXing.wood),
  /// 巽 ☴。
  xun('巽', WuXing.wood),
  /// 坎 ☵。
  kan('坎', WuXing.water),
  /// 艮 ☶。
  gen('艮', WuXing.earth),
  /// 坤 ☷。
  kun('坤', WuXing.earth);

  const Trigram(this.zh, this.wuxing);

  /// 中文名。
  final String zh;

  /// 五行。
  final WuXing wuxing;
}

/// 洛書九宮。
enum Palace {
  /// 坎一宮(北)。
  kan1('坎一', 1),
  /// 坤二宮(西南)。
  kun2('坤二', 2),
  /// 震三宮(東)。
  zhen3('震三', 3),
  /// 巽四宮(東南)。
  xun4('巽四', 4),
  /// 中五宮。
  center5('中五', 5),
  /// 乾六宮(西北)。
  qian6('乾六', 6),
  /// 兌七宮(西)。
  dui7('兌七', 7),
  /// 艮八宮(東北)。
  gen8('艮八', 8),
  /// 離九宮(南)。
  li9('離九', 9);

  const Palace(this.zh, this.number);

  /// 中文名。
  final String zh;

  /// 洛書數。
  final int number;
}

/// 九星(紫白)。
enum Star9 {
  /// 一白貪狼(水)。
  s1White('一白', WuXing.water),
  /// 二黑巨門(土)。
  s2Black('二黑', WuXing.earth),
  /// 三碧祿存(木)。
  s3Jade('三碧', WuXing.wood),
  /// 四綠文曲(木)。
  s4Green('四綠', WuXing.wood),
  /// 五黃廉貞(土)。
  s5Yellow('五黃', WuXing.earth),
  /// 六白武曲(金)。
  s6White('六白', WuXing.metal),
  /// 七赤破軍(金)。
  s7Red('七赤', WuXing.metal),
  /// 八白左輔(土)。
  s8White('八白', WuXing.earth),
  /// 九紫右弼(火)。
  s9Purple('九紫', WuXing.fire);

  const Star9(this.zh, this.wuxing);

  /// 中文名。
  final String zh;

  /// 五行。
  final WuXing wuxing;

  /// 星數(1–9)。
  int get number => index + 1;
}

/// 三元九運(每運 20 年)。
enum Period {
  /// 一運。
  p1,
  /// 二運。
  p2,
  /// 三運。
  p3,
  /// 四運。
  p4,
  /// 五運。
  p5,
  /// 六運。
  p6,
  /// 七運。
  p7,
  /// 八運。
  p8,
  /// 九運。
  p9;

  /// 運數(1–9)。
  int get number => index + 1;

  /// 由西元年取得所屬元運(以三元九運通行表:1864 起甲子上元一運)。
  ///
  /// 注意:嚴格分界是立春;此處以年為粒度,立春邊界由
  /// [CalendarEngine] 的歲界判定後再呼叫本方法。
  static Period fromYear(int year) {
    final offset = ((year - 1864) % 180 + 180) % 180;
    return Period.values[offset ~/ 20];
  }
}
