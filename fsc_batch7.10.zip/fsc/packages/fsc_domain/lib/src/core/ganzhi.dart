import 'cosmology.dart';

/// 十天干。
enum Stem {
  /// 甲。
  jia('甲', WuXing.wood),
  /// 乙。
  yi('乙', WuXing.wood),
  /// 丙。
  bing('丙', WuXing.fire),
  /// 丁。
  ding('丁', WuXing.fire),
  /// 戊。
  wu('戊', WuXing.earth),
  /// 己。
  ji('己', WuXing.earth),
  /// 庚。
  geng('庚', WuXing.metal),
  /// 辛。
  xin('辛', WuXing.metal),
  /// 壬。
  ren('壬', WuXing.water),
  /// 癸。
  gui('癸', WuXing.water);

  const Stem(this.zh, this.wuxing);

  /// 中文名。
  final String zh;

  /// 五行。
  final WuXing wuxing;

  /// 陽干?(甲丙戊庚壬)
  bool get isYang => index.isEven;
}

/// 十二地支。
enum Branch {
  /// 子。
  zi('子', WuXing.water),
  /// 丑。
  chou('丑', WuXing.earth),
  /// 寅。
  yin('寅', WuXing.wood),
  /// 卯。
  mao('卯', WuXing.wood),
  /// 辰。
  chen('辰', WuXing.earth),
  /// 巳。
  si('巳', WuXing.fire),
  /// 午。
  wuma('午', WuXing.fire),
  /// 未。
  wei('未', WuXing.earth),
  /// 申。
  shen('申', WuXing.metal),
  /// 酉。
  you('酉', WuXing.metal),
  /// 戌。
  xu('戌', WuXing.earth),
  /// 亥。
  hai('亥', WuXing.water);

  const Branch(this.zh, this.wuxing);

  /// 中文名。
  final String zh;

  /// 五行。
  final WuXing wuxing;

  /// 生肖(鼠…豬)。
  String get zodiac => const ['鼠', '牛', '虎', '兔', '龍', '蛇', '馬', '羊', '猴', '雞', '狗', '豬'][index];
}

/// 六十甲子納音(每兩柱一納音)。出處:《三命通會》通行表。
const List<String> naYin30 = [
  '海中金', '爐中火', '大林木', '路旁土', '劍鋒金', '山頭火',
  '澗下水', '城頭土', '白蠟金', '楊柳木', '泉中水', '屋上土',
  '霹靂火', '松柏木', '長流水', '沙中金', '山下火', '平地木',
  '壁上土', '金箔金', '覆燈火', '天河水', '大驛土', '釵釧金',
  '桑柘木', '大溪水', '沙中土', '天上火', '石榴木', '大海水',
];

/// 六十甲子(0=甲子 … 59=癸亥)。不可變值物件。
final class GanZhi {
  /// 以 0–59 索引建立。
  const GanZhi(this.index) : assert(index >= 0 && index < 60, 'index 0–59');

  /// 由干+支組合建立(干支陰陽必須相配,否則丟出 [ArgumentError])。
  factory GanZhi.of(Stem stem, Branch branch) {
    if (stem.index.isEven != branch.index.isEven) {
      throw ArgumentError('干支陰陽不相配:${stem.zh}${branch.zh} 不存在於六十甲子');
    }
    // 中國餘數定理:i ≡ stem (mod 10), i ≡ branch (mod 12)。
    final i = (6 * stem.index - 5 * branch.index) % 60;
    return GanZhi((i + 60) % 60);
  }

  /// 六十甲子序(0=甲子)。
  final int index;

  /// 天干。
  Stem get stem => Stem.values[index % 10];

  /// 地支。
  Branch get branch => Branch.values[index % 12];

  /// 中文(如「戊午」)。
  String get zh => stem.zh + branch.zh;

  /// 納音五行名(如「天上火」)。
  String get naYin => naYin30[index ~/ 2];

  /// 下一柱。
  GanZhi get next => GanZhi((index + 1) % 60);

  @override
  bool operator ==(Object other) => other is GanZhi && other.index == index;

  @override
  int get hashCode => index;

  @override
  String toString() => zh;
}
