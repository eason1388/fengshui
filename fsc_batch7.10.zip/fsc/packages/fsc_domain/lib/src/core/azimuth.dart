/// 方位角值物件。
///
/// 全 domain 層約定:**0–360°、真北基準、順時針**。
/// 磁北→真北換算在 fsc_sensors 層完成,domain 永遠只見真北(03 §2)。
extension type const Azimuth(double degrees) {
  /// 將任意角度正規化到 [0, 360)。
  Azimuth normalized() => Azimuth(((degrees % 360) + 360) % 360);

  /// 是否落在 [start, end) 區間內;正確處理跨 0° 區間(如壬山 337.5–352.5、子山 352.5–7.5)。
  bool isWithin(double start, double end) {
    final a = normalized().degrees;
    final s = ((start % 360) + 360) % 360;
    final e = ((end % 360) + 360) % 360;
    if (s <= e) return a >= s && a < e;
    return a >= s || a < e; // 跨 0°
  }

  /// 兩方位最短夾角(0–180)。
  double distanceTo(Azimuth other) {
    final d = (normalized().degrees - other.normalized().degrees).abs();
    return d > 180 ? 360 - d : d;
  }

  /// 對沖方位(+180°)。
  Azimuth get opposite => Azimuth(degrees + 180).normalized();
}
