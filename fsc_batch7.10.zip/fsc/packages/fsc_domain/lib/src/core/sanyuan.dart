import 'cosmology.dart';
import 'mountain24.dart';

/// 三元龍。
enum SanYuanDragon {
  /// 地元龍。
  earth('地元'),
  /// 天元龍。
  heaven('天元'),
  /// 人元龍。
  human('人元');

  const SanYuanDragon(this.zh);

  /// 中文。
  final String zh;
}

/// 二十四山之三元屬性(玄空挨星之基礎)。
extension Mountain24SanYuan on Mountain24 {
  /// 所屬卦宮(壬子癸=坎…戌乾亥=乾;每宮三山)。
  Palace get palace => const [
        Palace.kan1, Palace.gen8, Palace.zhen3, Palace.xun4,
        Palace.li9, Palace.kun2, Palace.dui7, Palace.qian6,
      ][index ~/ 3];

  /// 三元龍(每宮依序:地/天/人)。
  SanYuanDragon get dragon => SanYuanDragon.values[index % 3];

  /// 三元龍陰陽(陽順飛/陰逆飛)。
  /// 天元:乾坤艮巽陽、子午卯酉陰;地元:甲庚壬丙陽、辰戌丑未陰;
  /// 人元:寅申巳亥陽、乙辛丁癸陰。出處:沈氏玄空學。
  bool get isYangDragon => const {
        Mountain24.qian, Mountain24.kun, Mountain24.gen, Mountain24.xun,
        Mountain24.jia, Mountain24.geng, Mountain24.ren, Mountain24.bing,
        Mountain24.yin, Mountain24.shen, Mountain24.si, Mountain24.hai,
      }.contains(this);
}

/// 洛書宮位工具。
extension PalaceLuoShu on Palace {
  /// 宮之洛書數即 [Palace.number]。由數取宮:
  static Palace fromNumber(int n) =>
      Palace.values.firstWhere((p) => p.number == n);

  /// 該宮所轄三山(中宮丟出 [StateError])。
  List<Mountain24> get mountains {
    if (this == Palace.center5) throw StateError('中宮無山');
    const order = [
      Palace.kan1, Palace.gen8, Palace.zhen3, Palace.xun4,
      Palace.li9, Palace.kun2, Palace.dui7, Palace.qian6,
    ];
    final g = order.indexOf(this);
    return List.generate(3, (k) => Mountain24.values[g * 3 + k]);
  }
}
