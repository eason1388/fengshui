/// fsc_ui:設計系統。元件禁止寫死色值/字級,一律取用本庫 tokens(06 §6)。
library fsc_ui;

export 'src/tokens/colors.dart';
export 'src/tokens/motion.dart';
export 'src/tokens/spacing.dart';
export 'src/tokens/typography.dart';
