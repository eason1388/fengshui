/// 間距/圓角/觸控目標 tokens(04 §3.4)。4dp 網格。
abstract final class FscSpacing {
  /// 間距階。
  static const double xs = 4, sm = 8, md = 12, lg = 16, xl = 24, xxl = 32;
  /// 卡片圓角。
  static const double radiusCard = 16;
  /// 詳解卡圓角。
  static const double radiusSheet = 24;
  /// 最小觸控目標(標準/長者)。
  static const double touchTarget = 44, touchTargetElder = 56;
}
