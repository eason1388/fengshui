import 'package:flutter/material.dart';

/// 字體 tokens(04 §3.3)。盤面山向字=思源宋;介面=思源黑。
/// 長者模式:全域字級 ×1.25(由 theme scale 統一施加,元件不各自處理)。
abstract final class FscTypography {
  /// 盤面/判讀列用襯線字族。
  static const serifFamily = 'NotoSerifTC';
  /// 介面字族。
  static const sansFamily = 'NotoSansTC';

  /// 判讀列大字(28/34)。
  static const reading = TextStyle(
      fontFamily: serifFamily, fontSize: 28, fontWeight: FontWeight.w700, height: 1.2);
  /// 標題(20/24)。
  static const title = TextStyle(
      fontFamily: sansFamily, fontSize: 20, fontWeight: FontWeight.w500, height: 1.3);
  /// 正文(16/20)。
  static const body = TextStyle(fontFamily: sansFamily, fontSize: 16, height: 1.5);
  /// 註解/出處(13/16)。
  static const caption = TextStyle(fontFamily: sansFamily, fontSize: 13, height: 1.4);

  /// 長者模式縮放係數。
  static const elderScale = 1.25;
}
