import 'package:flutter/material.dart';

/// 色彩 tokens ——「玄金・宣紙」(04 §3.2,業主已確認)。
abstract final class FscColors {
  // 淺色(宣紙)
  /// 背景:宣紙白。
  static const surfaceLight = Color(0xFFFAF7F2);
  /// 卡片容器。
  static const containerLight = Color(0xFFF1ECE2);
  /// 主色:古銅金。
  static const primaryLight = Color(0xFF8C6D3F);
  /// 正文。
  static const onSurfaceLight = Color(0xFF2B2620);

  // 深色(玄墨)
  /// 背景:玄墨。
  static const surfaceDark = Color(0xFF12100D);
  /// 卡片容器。
  static const containerDark = Color(0xFF1C1915);
  /// 主色:鎏金。
  static const primaryDark = Color(0xFFC9A96A);
  /// 正文。
  static const onSurfaceDark = Color(0xFFE8E2D6);

  // 語意色(吉凶永遠搭配圖示,不單靠顏色──色盲友善)
  /// 凶/警告:朱砂。
  static const inauspicious = Color(0xFFA63A2E);
  /// 吉:竹青。
  static const auspicious = Color(0xFF4A6B4F);
  /// 資訊/水。
  static const info = Color(0xFF3E5C76);

  /// 五行色(圈層著色一致性)。
  static const wuxing = {
    'wood': Color(0xFF4A6B4F),
    'fire': Color(0xFFA63A2E),
    'earth': Color(0xFF8C6D3F),
    'metal': Color(0xFFB8B2A5),
    'water': Color(0xFF3E5C76),
  };
}
