import 'package:flutter/animation.dart';

/// 動效 tokens(04 §3.5)。全域尊重系統「減少動態」→ 降級為淡入淡出。
abstract final class FscMotion {
  /// 圈層展開/收合。
  static const ringToggle = Duration(milliseconds: 250);
  /// 詳解卡彈出。
  static const sheet = Duration(milliseconds: 300);
  /// 教學模式飛星入宮。
  static const starFlight = Duration(milliseconds: 1200);
  /// 標準曲線。
  static const curve = Curves.easeOutCubic;
  /// 羅盤回彈 spring 參數(stiffness/damping)。
  static const springStiffness = 180.0, springDamping = 20.0;
}
