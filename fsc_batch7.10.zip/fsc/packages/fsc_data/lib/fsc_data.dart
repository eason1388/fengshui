/// fsc_data:drift schema 與 repositories(批次 7.7 先交付 schema;
/// DAO/同步佇列於 7.8 隨雲端接線交付)。
library fsc_data;

export 'src/user_db.dart';
