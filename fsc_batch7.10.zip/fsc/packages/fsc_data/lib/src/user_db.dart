import 'package:drift/drift.dart';

/// 使用者資料庫 schema(02 §3;SQLCipher 於 app 層以
/// NativeDatabase + pragma key 開啟;persons 出生欄位另做欄位級加密)。
/// 共通同步欄位:uuid/created/updated/rev/deletedAt/dirty(02 §3.2)。

/// 專案(案場)。
class Projects extends Table {
  /// UUID 主鍵。
  TextColumn get uuid => text()();
  /// 名稱。
  TextColumn get name => text()();
  /// 模式:yangzhai/yinzhai/factory/shop/office/longmai。
  TextColumn get mode => text()();
  /// 地址。
  TextColumn get address => text().nullable()();
  /// 座標。
  RealColumn get lat => real().nullable()();
  /// 座標。
  RealColumn get lng => real().nullable()();
  /// 同步欄位。
  DateTimeColumn get createdAt => dateTime()();
  /// 同步欄位。
  DateTimeColumn get updatedAt => dateTime()();
  /// 遞增版本。
  IntColumn get rev => integer().withDefault(const Constant(0))();
  /// 軟刪除。
  DateTimeColumn get deletedAt => dateTime().nullable()();
  /// 待上傳。
  BoolColumn get dirty => boolean().withDefault(const Constant(true))();

  @override
  Set<Column> get primaryKey => {uuid};
}

/// 建物。
class Sites extends Table {
  /// UUID。
  TextColumn get uuid => text()();
  /// 所屬專案。
  TextColumn get projectUuid => text().references(Projects, #uuid)();
  /// 輪廓 GeoJSON。
  TextColumn get footprint => text().nullable()();
  /// 立極點。
  RealColumn get jiJiLat => real().nullable()();
  /// 立極點。
  RealColumn get jiJiLng => real().nullable()();
  /// 坐(真北)。
  RealColumn get sittingDeg => real().nullable()();
  /// 建造元運 1–9。
  IntColumn get constructionPeriod => integer().nullable()();
  /// 同步欄位(同上,略註)。
  DateTimeColumn get createdAt => dateTime()();
  /// 更新時間。
  DateTimeColumn get updatedAt => dateTime()();
  /// 版本。
  IntColumn get rev => integer().withDefault(const Constant(0))();
  /// 軟刪除。
  DateTimeColumn get deletedAt => dateTime().nullable()();
  /// 待上傳。
  BoolColumn get dirty => boolean().withDefault(const Constant(true))();

  @override
  Set<Column> get primaryKey => {uuid};
}

/// 量測記錄(BearingReading 快照,含引擎版本以便重跑)。
class Measurements extends Table {
  /// UUID。
  TextColumn get uuid => text()();
  /// 建物。
  TextColumn get siteUuid => text().references(Sites, #uuid)();
  /// 原始讀數(真北)。
  RealColumn get rawDeg => real()();
  /// 讀坐或向。
  BoolColumn get isSitting => boolean()();
  /// 精度等級 high/medium/low。
  TextColumn get accuracy => text()();
  /// 判讀快照 JSON(BearingReading)。
  TextColumn get derived => text()();
  /// 判讀引擎版本。
  TextColumn get engineVersion => text()();
  /// 量測時刻。
  DateTimeColumn get measuredAt => dateTime()();

  @override
  Set<Column> get primaryKey => {uuid};
}

/// 屋主(出生資料於 app 層 AES-GCM 加密後存入 *Enc 欄)。
class Persons extends Table {
  /// UUID。
  TextColumn get uuid => text()();
  /// 專案。
  TextColumn get projectUuid => text().references(Projects, #uuid)();
  /// 稱呼。
  TextColumn get name => text()();
  /// 性別。
  BoolColumn get isMale => boolean()();
  /// 出生時刻密文(AES-GCM)。
  TextColumn get birthEnc => text()();
  /// 時辰不確定。
  BoolColumn get hourUncertain => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {uuid};
}

/// 分析結果(不可變:只插入;input 快照+引擎版本=可重現,02 §3.2)。
class Analyses extends Table {
  /// UUID。
  TextColumn get uuid => text()();
  /// 專案。
  TextColumn get projectUuid => text().references(Projects, #uuid)();
  /// 輸入快照 JSON。
  TextColumn get inputSnapshot => text()();
  /// 各引擎版本 JSON。
  TextColumn get engineVersions => text()();
  /// 分數與逐項依據 JSON(IntegrationResult)。
  TextColumn get scores => text()();
  /// 建立時間。
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {uuid};
}
