/// AI 供應商抽象(正式版:Claude API 經後端代理;金鑰不入 App,06 §3)。
abstract interface class AiProvider {
  /// 串流回覆。
  Stream<String> complete({required String system, required String user});
}

/// 測試/離線用假供應商。
final class MockAiProvider implements AiProvider {
  /// 建立。
  const MockAiProvider(this.cannedReply);

  /// 固定回覆。
  final String cannedReply;

  @override
  Stream<String> complete({required String system, required String user}) =>
      Stream.fromIterable(cannedReply.split(' '));
}
