import 'dart:math' as math;

/// 知識片段(glossary/article/theory_rule 統一格式)。
final class KnowledgeChunk {
  /// 建立。
  const KnowledgeChunk({
    required this.id,
    required this.kind,
    required this.title,
    required this.text,
    required this.sourceRef,
  });

  /// id(引用錨)。
  final String id;

  /// glossary / article / rule。
  final String kind;

  /// 標題。
  final String title;

  /// 內文。
  final String text;

  /// 出處。
  final String sourceRef;
}

/// 輕量 TF-IDF 檢索(中文以字元 bigram 斷詞;離線可用,02 §3 FTS 之演算法層)。
final class LocalRetriever {
  /// 建索引。
  LocalRetriever(this.chunks) {
    for (var i = 0; i < chunks.length; i++) {
      final grams = _grams('${chunks[i].title} ${chunks[i].text}');
      _docs.add(grams);
      for (final g in grams.keys) {
        _df[g] = (_df[g] ?? 0) + 1;
      }
    }
  }

  /// 全部片段。
  final List<KnowledgeChunk> chunks;
  final List<Map<String, int>> _docs = [];
  final Map<String, int> _df = {};

  Map<String, int> _grams(String s) {
    final t = s.replaceAll(RegExp(r'\s'), '');
    final out = <String, int>{};
    for (var i = 0; i + 1 < t.length; i++) {
      final g = t.substring(i, i + 2);
      out[g] = (out[g] ?? 0) + 1;
    }
    return out;
  }

  /// 查詢:回傳依 TF-IDF 排序之前 [k] 片段。
  List<KnowledgeChunk> query(String q, {int k = 5}) {
    final qg = _grams(q);
    final n = chunks.length;
    final scored = <(double, KnowledgeChunk)>[];
    for (var i = 0; i < n; i++) {
      var s = 0.0;
      qg.forEach((g, qc) {
        final tf = _docs[i][g] ?? 0;
        if (tf > 0) s += qc * tf * math.log(n / (_df[g] ?? 1) + 1);
      });
      // 標題精確命中強力加權:問句直接含詞條名時,該詞條優先。
      if (s > 0 && q.contains(chunks[i].title)) s += 100;
      if (s > 0) scored.add((s, chunks[i]));
    }
    scored.sort((a, b) => b.$1.compareTo(a.$1));
    return scored.take(k).map((e) => e.$2).toList();
  }
}
