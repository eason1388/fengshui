import 'retriever.dart';

/// 組裝 AI 顧問提示詞:羅盤/宅盤/八字上下文 + 檢索片段(RAG)。
/// system 提示強制:僅可引用 <refs> 內片段並標 [id];
/// 無出處之推論須以「(AI 推測)」開頭——UI 據此渲染灰標(05 §6)。
final class PromptBuilder {
  /// 建立。
  const PromptBuilder();

  /// 系統提示。
  String system() => '''
你是專業風水顧問。規則:
1. 所有盤面數據以 <context> 內引擎輸出為準,禁止自行排盤或更改數字。
2. 論斷必須引用 <refs> 內片段,句末標 [id];找不到依據的推論,句首標「(AI 推測)」。
3. 先結論、再推導、再出處;白話,長者可懂。
4. 涉及健康/財務決策時提醒僅供參考。''';

  /// 使用者訊息(上下文+檢索+問題)。
  String user({
    required String contextJson,
    required List<KnowledgeChunk> refs,
    required String question,
  }) {
    final refBlock = refs
        .map((r) => '[${r.id}] ${r.title}(${r.sourceRef}):${r.text}')
        .join('\n');
    return '<context>\n$contextJson\n</context>\n<refs>\n$refBlock\n</refs>\n問題:$question';
  }
}
