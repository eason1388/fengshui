/// fsc_ai:AI 顧問層。
/// 原則(01 §9 風險4):排盤一律演算法計算,AI 只解說;
/// 回答只能引用檢索到的本地理論庫片段,無出處之句標「AI 推測」。
library fsc_ai;

export 'src/ai_provider.dart';
export 'src/prompt_builder.dart';
export 'src/retriever.dart';
