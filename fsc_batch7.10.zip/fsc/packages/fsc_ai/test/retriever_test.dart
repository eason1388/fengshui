import 'package:fsc_ai/fsc_ai.dart';
import 'package:test/test.dart';

void main() {
  final r = LocalRetriever(const [
    KnowledgeChunk(id: 'g1', kind: 'glossary', title: '騎縫線',
        text: '羅盤讀數壓在兩山交界之線,主氣雜,立向所忌。', sourceRef: '通行羅經解'),
    KnowledgeChunk(id: 'g2', kind: 'glossary', title: '旺山旺向',
        text: '山星到坐向星到向,丁財兩旺之局。', sourceRef: '沈氏玄空學'),
    KnowledgeChunk(id: 'r1', kind: 'rule', title: '二五交加',
        text: '二黑五黃同宮主病符,忌臥室,宜金洩。', sourceRef: '沈氏玄空學·卷四'),
  ]);

  test('「什麼叫騎縫線?」→ 命中 g1 為首', () {
    final hits = r.query('什麼叫騎縫線?');
    expect(hits.first.id, 'g1');
  });
  test('標題精確命中優先:「騎縫線」勝過內文含線位之詞條', () {
    expect(r.query('騎縫線').first.id, 'g1');
  });
  test('「二黑五黃同宮怎麼辦」→ 命中 r1', () {
    expect(r.query('二黑五黃同宮怎麼辦').first.id, 'r1');
  });
  test('PromptBuilder 引用塊含 id 與出處', () {
    const pb = PromptBuilder();
    final u = pb.user(
        contextJson: '{"sitting":"壬"}',
        refs: r.query('旺山旺向'),
        question: '這局如何?');
    expect(u, contains('[g2]'));
    expect(u, contains('沈氏玄空學'));
    expect(pb.system(), contains('AI 推測'));
  });
}
